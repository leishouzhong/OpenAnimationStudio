package org.openanimationstudio.data

import java.io.File
import java.util.UUID
import kotlinx.coroutines.flow.Flow

class WorkspaceRepository(private val dao: AppDao) {
    fun projects(): Flow<List<ProjectEntity>> = dao.observeProjects()
    fun shots(projectId: String): Flow<List<ShotEntity>> = dao.observeShots(projectId)
    fun characters(projectId: String): Flow<List<CharacterEntity>> = dao.observeCharacters(projectId)
    fun versions(characterId: String): Flow<List<CharacterCardVersionEntity>> = dao.observeCardVersions(characterId)
    fun scenes(projectId: String): Flow<List<SceneEntity>> = dao.observeScenes(projectId)
    fun props(projectId: String): Flow<List<PropEntity>> = dao.observeProps(projectId)
    suspend fun getProject(projectId: String): ProjectEntity? = dao.getProject(projectId)
    suspend fun createProject(name: String): String {
        val id = UUID.randomUUID().toString()
        dao.upsertProject(ProjectEntity(id, name.trim().ifBlank { "未命名项目" }))
        return id
    }
    suspend fun saveScript(projectId: String, text: String) = dao.updateScript(projectId, text)
    suspend fun appendShot(projectId: String, index: Int, title: String, description: String, durationMs: Long = 6000L) {
        dao.upsertShot(ShotEntity(UUID.randomUUID().toString(), projectId, index, title, description, durationMs = durationMs))
    }
    suspend fun importShotsFromScript(projectId: String, script: String): Int {
        val parsed = ScriptParser.parse(script)
        if (parsed.isEmpty()) return 0
        val existingCount = dao.getShotsForProject(projectId).size
        parsed.forEachIndexed { idx, item ->
            dao.upsertShot(
                ShotEntity(
                    id = UUID.randomUUID().toString(),
                    projectId = projectId,
                    orderIndex = existingCount + idx,
                    title = item.title,
                    description = item.description,
                    durationMs = item.durationMs
                )
            )
        }
        return parsed.size
    }
    suspend fun saveShot(shot: ShotEntity) = dao.upsertShot(shot)
    suspend fun getShot(shotId: String): ShotEntity? = dao.getShot(shotId)
    suspend fun deleteShot(shotId: String, projectId: String) = dao.deleteShotAndNormalize(shotId, projectId)
    suspend fun swapShotOrder(a: ShotEntity, b: ShotEntity) = dao.swapShotOrder(a, b)

    suspend fun createCharacter(projectId: String, name: String, asset: ImportedAsset): String {
        val id = UUID.randomUUID().toString()
        dao.upsertCharacter(CharacterEntity(id, projectId, name.trim().ifBlank { "未命名角色" }))
        addCardVersion(id, asset)
        return id
    }
    suspend fun addCardVersion(characterId: String, asset: ImportedAsset): CharacterCardVersionEntity {
        // Version number is computed from persisted version history.
        val versions = dao.getCardVersionNumbers(characterId)
        val version = CharacterCardVersionEntity(
            UUID.randomUUID().toString(), characterId, (versions.maxOrNull() ?: 0) + 1,
            asset.absolutePath, asset.sha256
        )
        dao.insertCardVersion(version)
        dao.setActiveCardVersion(characterId, version.id)
        return version
    }
    suspend fun setLocked(characterId: String, locked: Boolean) = dao.setCharacterLocked(characterId, locked)
    suspend fun restoreVersion(characterId: String, versionId: String) {
        val version = dao.getCardVersion(versionId) ?: error("角色卡版本不存在")
        require(version.characterId == characterId) { "版本不属于该角色" }
        dao.setActiveCardVersion(characterId, versionId)
    }
    suspend fun bindCharacterVersion(shotId: String, characterId: String, versionId: String) {
        val version = dao.getCardVersion(versionId) ?: error("角色卡版本不存在")
        require(version.characterId == characterId) { "角色卡版本与角色不匹配" }
        dao.deleteShotCharacterReference(shotId, characterId)
        dao.insertShotCharacterReference(
            ShotCharacterReferenceEntity(
                UUID.randomUUID().toString(), shotId, characterId, version.id,
                version.primaryAssetPath, version.checksumSha256
            )
        )
    }
    suspend fun addScene(projectId: String, name: String, imagePath: String? = null) {
        dao.upsertScene(SceneEntity(UUID.randomUUID().toString(), projectId, name.trim(), imagePath))
    }
    suspend fun addProp(projectId: String, name: String, imagePath: String? = null) {
        dao.upsertProp(PropEntity(UUID.randomUUID().toString(), projectId, name.trim(), imagePath))
    }
    suspend fun checkShotAssets(shotId: String): List<String> {
        val shot = dao.getShot(shotId) ?: return listOf("镜头记录不存在")
        val issues = mutableListOf<String>()
        if (shot.firstFramePath.isNullOrBlank()) issues += "缺少首帧"
        else if (!File(shot.firstFramePath).exists()) issues += "首帧文件丢失"
        if (shot.lastFramePath.isNullOrBlank()) issues += "缺少尾帧"
        else if (!File(shot.lastFramePath).exists()) issues += "尾帧文件丢失"
        dao.getShotCharacterReferences(shotId).forEach {
            if (!File(it.assetPathSnapshot).exists()) issues += "角色参考图文件丢失：${it.characterId}"
        }
        return issues
    }
    suspend fun bindCharacterVersionLegacy(
        shotId: String, characterId: String, versionId: String, assetPath: String, checksum: String
    ) {
        dao.insertShotCharacterReference(
            ShotCharacterReferenceEntity(UUID.randomUUID().toString(), shotId, characterId, versionId, assetPath, checksum)
        )
    }
}
