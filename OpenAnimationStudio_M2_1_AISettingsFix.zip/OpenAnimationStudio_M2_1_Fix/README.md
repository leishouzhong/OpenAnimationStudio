# Open Animation Studio — 2.1.0

Android 原生动画制作工具。当前版本以本地项目管理和基础动画制作作为底座，并提供可配置的在线 AI 服务接入。**应用不是纯离线 AI 应用，也不要求所有功能必须联网：**项目数据、素材管理、分镜编辑、时间轴编辑及本地 MP4 合成可在无网络时使用；调用云端文本/图片/视频服务时需要网络和相应服务商的 API 配置。

## 版本信息

- 应用版本：`2.1.0`
- `versionCode`：`21`
- Android `minSdk`：26
- `compileSdk`：35
- Kotlin / Java 目标版本：17
- UI：Jetpack Compose
- 本地数据：Room

版本号以 `app/build.gradle.kts` 的 `defaultConfig` 为准。

## 当前已有模块

- 项目、角色、场景、道具及素材管理
- 剧本与分镜工作流程
- AI 服务配置与客户端：文本、图片、视频服务请求
- 时间轴：镜头选择、排序、时长设置、首尾帧/视频预览、音效导入与播放
- MP4 导出：使用 Android `MediaCodec` 编码视频，并通过 `MediaMuxer` 封装 MP4

具体能力以当前源码实现为准；尚未实现或未经验证的能力不会视为已交付功能。

## 网络与离线边界

- Manifest 声明 `INTERNET` 权限，用于访问用户配置的在线 AI 服务。
- 无网络时，已下载到本地的项目和素材仍可进行本地管理与编辑。
- 云端 AI 请求、远程图片/视频生成及远程资源下载需要网络。
- 本版本不应描述为“完全离线 AI”；本地编辑与导出能力也不代表本地运行了生成式 AI 模型。
- 使用在线 AI 服务可能产生服务商费用，API Key 由用户自行配置并妥善保管。

## 构建

使用 Android Studio 打开本项目，在具备匹配 Android SDK、JDK 17 和 Gradle 环境的设备上执行：

```bash
./gradlew :app:assembleDebug
```

当前源码包尚未在本次修订环境完成 Android Gradle 构建，也未完成真机回归测试。请勿将本源码包描述为已验证可安装版本。

## 目录重点

- `app/src/main/java/org/openanimationstudio/data/`：Room 数据、项目仓库、AI 配置与客户端
- `app/src/main/java/org/openanimationstudio/ui/TimelineScreen.kt`：时间轴界面与预览逻辑
- `app/src/main/java/org/openanimationstudio/export/Mp4Exporter.kt`：MP4 编码与封装
- `app/src/main/AndroidManifest.xml`：Android 权限和应用配置

## 修订记录

### 2.1.0 文档校正

- 将过期的 M1.5 README 更新为与 Gradle `versionName=2.1.0`、`versionCode=21` 一致。
- 修正“完全离线、无 INTERNET 权限”等与当前 Manifest 不符的描述。
- 记录当前源码中已存在的时间轴、AI 客户端和 MediaCodec/MediaMuxer 导出模块。
- 明确本次仅完成文档校正，尚未宣称完成编译或真机验证。


### AI 接口兼容范围（M2.1 修订）
当前文本和生图请求按 OpenAI-compatible API 格式发送。填写的服务商必须兼容对应接口路径与请求/响应格式；仅修改接口地址并不代表支持该服务商的原生协议。Gemini 原生接口与 AI Horde 原生协议尚未实现。视频接口使用项目中单独的提交/轮询协议。
