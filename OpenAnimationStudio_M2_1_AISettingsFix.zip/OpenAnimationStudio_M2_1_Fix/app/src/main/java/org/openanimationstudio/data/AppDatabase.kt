package org.openanimationstudio.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProjectEntity::class, CharacterEntity::class, CharacterCardVersionEntity::class,
        ShotEntity::class, ShotCharacterReferenceEntity::class, GenerationSnapshotEntity::class,
        SceneEntity::class, PropEntity::class, SharedAssetEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `scenes` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS `props` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startScale` REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endScale` REAL NOT NULL DEFAULT 1.08")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startOffsetX` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startOffsetY` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endOffsetX` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endOffsetY` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `fadeInMs` INTEGER NOT NULL DEFAULT 300")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `fadeOutMs` INTEGER NOT NULL DEFAULT 300")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `audioPath` TEXT")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `audioStartMs` INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `videoClipPath` TEXT")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `muteOriginalAudio` INTEGER NOT NULL DEFAULT 1")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `motionPreset` TEXT NOT NULL DEFAULT 'NONE'")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `projects` ADD COLUMN `visualStyle` TEXT NOT NULL DEFAULT '极简2D死鱼眼线稿（黑线白底、冷幽默）'")
                db.execSQL("ALTER TABLE `characters` ADD COLUMN `appearance` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `firstFramePrompt` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `motionPrompt` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `sceneName` TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `shared_assets` (
                    `id` TEXT NOT NULL, `kind` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `prompt` TEXT NOT NULL, `imagePath` TEXT, `createdAt` INTEGER NOT NULL,
                    PRIMARY KEY(`id`))""")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "open_animation_studio.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build().also { INSTANCE = it }
        }
    }
}
