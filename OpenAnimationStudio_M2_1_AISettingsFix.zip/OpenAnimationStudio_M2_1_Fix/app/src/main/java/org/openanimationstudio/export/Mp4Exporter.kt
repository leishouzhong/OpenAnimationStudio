package org.openanimationstudio.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.openanimationstudio.data.ShotEntity
import java.io.File
import kotlin.math.max
import kotlin.math.sin

object Mp4Exporter {
    private const val WIDTH = 1280
    private const val HEIGHT = 720
    private const val FPS = 24
    private const val BITRATE = 4_000_000

    suspend fun exportShotsToMp4(
        context: Context,
        shots: List<ShotEntity>,
        outputName: String,
        onProgress: (Float) -> Unit
    ): String = withContext(Dispatchers.IO) {
        require(shots.isNotEmpty()) { "没有可导出的镜头" }
        val tempFile = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, WIDTH, HEIGHT).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = encoder.createInputSurface()
        encoder.start()

        val muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false
        var outFrameIndex = 0L
        val bufferInfo = MediaCodec.BufferInfo()

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val status = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
                when {
                    status == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) break
                    status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!muxerStarted) {
                            trackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    }
                    status >= 0 -> {
                        val encodedData = encoder.getOutputBuffer(status)
                        if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                bufferInfo.presentationTimeUs = outFrameIndex * 1_000_000L / FPS
                                outFrameIndex++
                                encodedData.position(bufferInfo.offset)
                                encodedData.limit(bufferInfo.offset + bufferInfo.size)
                                muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                            }
                        }
                        encoder.releaseOutputBuffer(status, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
        }

        val totalFramesAll = shots.sumOf { ((it.durationMs.coerceAtLeast(500L) * FPS) / 1000L).toInt().coerceAtLeast(1) }
        var renderedFrames = 0
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        try {
            for (shot in shots) {
                val hasVideo = !shot.videoClipPath.isNullOrBlank() && File(shot.videoClipPath).exists()
                val frameCount = ((shot.durationMs.coerceAtLeast(500L) * FPS) / 1000L).toInt().coerceAtLeast(1)

                if (hasVideo) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(shot.videoClipPath)
                        val clipDurMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: shot.durationMs
                        var cachedBmp: Bitmap? = null
                        for (f in 0 until frameCount) {
                            if (f % 2 == 0 || cachedBmp == null) {
                                val timeUs = ((f.toFloat() / frameCount.toFloat()) * clipDurMs * 1000f).toLong().coerceAtLeast(0L)
                                val nextBmp = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                                    ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                                if (nextBmp != null) {
                                    cachedBmp?.recycle()
                                    cachedBmp = nextBmp
                                }
                            }
                            val canvas = inputSurface.lockCanvas(null)
                            try {
                                canvas.drawColor(Color.rgb(18, 18, 22))
                                cachedBmp?.let { drawTransformedBitmap(canvas, it, 1.0f, 0f, 0f, 255, paint) }
                            } finally {
                                inputSurface.unlockCanvasAndPost(canvas)
                            }
                            drainEncoder(false)
                            renderedFrames++
                            if (renderedFrames % 4 == 0 || renderedFrames == totalFramesAll) {
                                onProgress(renderedFrames.toFloat() / totalFramesAll.toFloat())
                            }
                        }
                        cachedBmp?.recycle()
                    } finally {
                        runCatching { retriever.release() }
                    }
                } else {
                    val firstBmp = shot.firstFramePath?.let { decodeForVideo(it) }
                    val lastBmp = shot.lastFramePath?.let { decodeForVideo(it) }
                    for (f in 0 until frameCount) {
                        val progress = f.toFloat() / frameCount.toFloat()
                        val elapsedMs = (f * 1000L) / FPS
                        val durMs = shot.durationMs.coerceAtLeast(500L).toFloat()
                        var scale = 1.0f
                        var offX = 0f
                        var offY = 0f
                        when (shot.motionPreset) {
                            "SLOW_ZOOM" -> scale = 1.0f + 0.12f * progress
                            "POP_IN" -> scale = if (progress < 0.15f) 1.0f + 0.35f * (progress / 0.15f) else 1.35f
                            "SHAKE" -> {
                                scale = 1.06f
                                offX = sin(progress * 45f) * 0.025f
                                offY = sin(progress * 32f) * 0.015f
                            }
                            "FLOAT" -> {
                                scale = 1.04f
                                offY = sin(progress * 10f) * 0.035f
                            }
                        }
                        val fadeIn = if (shot.fadeInMs > 0) (elapsedMs / shot.fadeInMs.toFloat()).coerceIn(0f, 1f) else 1f
                        val fadeOut = if (shot.fadeOutMs > 0) ((durMs - elapsedMs) / shot.fadeOutMs.toFloat()).coerceIn(0f, 1f) else 1f
                        val alpha = (minOf(fadeIn, fadeOut) * 255f).toInt().coerceIn(0, 255)

                        val canvas = inputSurface.lockCanvas(null)
                        try {
                            canvas.drawColor(Color.rgb(18, 18, 22))
                            val activeBmp = if (firstBmp != null && lastBmp != null && progress > 0.5f) lastBmp else (firstBmp ?: lastBmp)
                            activeBmp?.let { drawTransformedBitmap(canvas, it, scale, offX, offY, alpha, paint) }
                        } finally {
                            inputSurface.unlockCanvasAndPost(canvas)
                        }
                        drainEncoder(false)
                        renderedFrames++
                        if (renderedFrames % 4 == 0 || renderedFrames == totalFramesAll) {
                            onProgress(renderedFrames.toFloat() / totalFramesAll.toFloat())
                        }
                    }
                    firstBmp?.recycle()
                    lastBmp?.recycle()
                }
            }
            drainEncoder(true)
        } finally {
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { inputSurface.release() }
            runCatching { if (muxerStarted) muxer.stop() }
            runCatching { muxer.release() }
        }

        val finalLabel = saveToMovies(context, tempFile, outputName)
        tempFile.delete()
        finalLabel
    }

    private fun drawTransformedBitmap(
        canvas: Canvas,
        bmp: Bitmap,
        scale: Float,
        offX: Float,
        offY: Float,
        alpha: Int,
        paint: Paint
    ) {
        paint.alpha = alpha
        val baseScale = max(WIDTH.toFloat() / bmp.width, HEIGHT.toFloat() / bmp.height) * scale
        val drawW = bmp.width * baseScale
        val drawH = bmp.height * baseScale
        val cx = WIDTH / 2f + offX * WIDTH
        val cy = HEIGHT / 2f + offY * HEIGHT
        val dst = RectF(cx - drawW / 2f, cy - drawH / 2f, cx + drawW / 2f, cy + drawH / 2f)
        canvas.drawBitmap(bmp, null, dst, paint)
    }

    private fun decodeForVideo(path: String): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        var sample = 1
        while (bounds.outWidth / sample > WIDTH || bounds.outHeight / sample > HEIGHT) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()

    private fun saveToMovies(context: Context, source: File, title: String): String {
        val safeName = title.replace(Regex("""[^\w\u4e00-\u9fa5\-]"""), "_").ifBlank { "OpenAnimation" }
        val fileName = "${safeName}_${System.currentTimeMillis() / 1000}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/OpenAnimationStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    source.inputStream().use { it.copyTo(out) }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return "已导出到相册：Movies/OpenAnimationStudio/$fileName"
            }
        }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        val dst = File(dir, fileName)
        source.copyTo(dst, overwrite = true)
        return "已导出到：${dst.absolutePath}"
    }
}
