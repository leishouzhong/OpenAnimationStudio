# M2.1 源码状态核对

核对对象：`OpenAnimationStudio_M2_1_CloudBuild.zip`

| 项目 | 源码核对结果 | 说明 |
|---|---|---|
| 应用版本 | `versionName = 2.1.0`、`versionCode = 21` | 位于 `app/build.gradle.kts` |
| 网络权限 | 声明 `android.permission.INTERNET` | 在线 AI 请求需要网络；本地编辑流程不因此自动变成联网依赖 |
| 时间轴 | 存在 `TimelineScreen.kt` | 包含镜头播放、时长、排序、音效导入等实现；仍需设备交互回归测试 |
| AI 客户端 | 存在 `AiClient.kt`、`AiSettings.kt` | 当前请求层包含 OpenAI 兼容 Chat Completions 风格调用；供应商兼容性需逐家验证 |
| MP4 导出 | 存在 `Mp4Exporter.kt` | 使用 `MediaCodec` 与 `MediaMuxer`；暂不重写，后续针对导出异常单独测试 |

## 本次修订

- README 从 M1.5 更新为 2.1.0。
- 更新功能清单、网络/离线边界、构建说明和未验证声明。
- 不改动数据库结构、AI 请求协议、时间轴业务逻辑或 MP4 编码实现。

## 尚待验证

- Android Gradle 构建及 APK 安装。
- 时间轴横竖屏、空镜头、镜头切换、音效播放与时长调整。
- 不同网络状态下 AI 请求的错误提示与重试体验。
- MP4 导出在目标设备上的编码器兼容性、音画同步和长视频稳定性。


## 本轮修订：AI Provider 配置一致性

- 修复 `AiSettingsStore.load()`：从 SharedPreferences 读取并恢复 `textProviderType`、`imageProviderType`，不再每次启动都强制覆盖为 `OPENAI`。
- 核对 `MainActivity`：当前 AI 设置界面只提供接口地址、模型名和 API Key，没有供应商类型选择控件。
- 核对 `AiClient`：文本请求实际使用 OpenAI-compatible `chat/completions`；生图请求实际使用 OpenAI-compatible `images/generations`。当前代码没有实现 Gemini 原生 API 或 AI Horde 原生协议。
- 为避免配置值被静默忽略，文本/生图请求在 provider 类型不是 `OPENAI` 时会明确报错；设置页同步标明当前协议范围。
- 本次未宣称 Gemini 或 AI Horde 已可用；后续需分别实现并测试原生 Provider Adapter 后再开放选择。
- 本轮为静态源码修改，尚未在本环境执行 Android Gradle 构建或真机测试。
