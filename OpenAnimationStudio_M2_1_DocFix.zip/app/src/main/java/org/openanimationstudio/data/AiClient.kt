package org.openanimationstudio.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class AssetPlanItem(val name: String, val prompt: String)

data class PreparedAssets(
    val story: String,
    val characters: List<AssetPlanItem>,
    val scenes: List<AssetPlanItem>,
    val props: List<AssetPlanItem>
)

data class PlannedShot(
    val title: String,
    val description: String,
    val sceneName: String,
    val characterNames: List<String>,
    val firstFramePrompt: String,
    val motionPrompt: String,
    val durationMs: Long
)

object AiClient {
    suspend fun testTextConnection(cfg: AiConfig): String = callTextLlm(
        cfg,
        "请只回复：连接正常，可以开始制作动画。"
    )

    suspend fun prepareAssetsFromStory(cfg: AiConfig, style: String, storyOrIdea: String): PreparedAssets = withContext(Dispatchers.IO) {
        val silentRule = if (cfg.silentMode) "无声动画风格（无对白、无背景音乐、靠画面反差搞笑）。" else ""
        val prompt = """
            你是专业动画制片人。请根据用户输入的“一句话灵感或完整故事”，整理出完整故事并提取出需要提前定稿的【角色】【场景】【道具】。
            画风要求：$style。$silentRule
            请严格只输出一个 JSON 对象，不要有任何多余解释文字：
            {
              "story": "整理后的完整短片故事（中文）",
              "characters": [
                {"name": "角色中文名", "prompt": "English character design prompt, full body or portrait, isolated on clean background, matching style"}
              ],
              "scenes": [
                {"name": "场景中文名", "prompt": "English background environment prompt without characters, matching style"}
              ],
              "props": [
                {"name": "道具中文名", "prompt": "English single prop item prompt, isolated on clean background, matching style"}
              ]
            }

            用户输入：
            $storyOrIdea
        """.trimIndent()

        val raw = callTextLlm(cfg, prompt)
        val json = extractJsonObject(raw)
        val story = json.optString("story", storyOrIdea).ifBlank { storyOrIdea }
        fun parseArr(key: String): List<AssetPlanItem> {
            val arr = json.optJSONArray(key) ?: return emptyList()
            val out = mutableListOf<AssetPlanItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val n = obj.optString("name", "").trim()
                val p = obj.optString("prompt", "").trim()
                if (n.isNotBlank()) out += AssetPlanItem(n, p.ifBlank { n })
            }
            return out
        }
        PreparedAssets(
            story = story,
            characters = parseArr("characters"),
            scenes = parseArr("scenes"),
            props = parseArr("props")
        )
    }

    suspend fun planStoryboardFromAssets(
        cfg: AiConfig,
        style: String,
        story: String,
        characters: List<CharacterEntity>,
        scenes: List<SceneEntity>,
        props: List<PropEntity>
    ): List<PlannedShot> = withContext(Dispatchers.IO) {
        val charInfo = characters.joinToString("; ") { "${it.name}(${it.appearance.ifBlank { it.name }})" }
        val sceneInfo = scenes.joinToString("; ") { "${it.name}(${it.notes.ifBlank { it.name }})" }
        val propInfo = props.joinToString("; ") { "${it.name}(${it.notes.ifBlank { it.name }})" }
        val silentRule = if (cfg.silentMode) "Every motionPrompt must specify: silent animation, no background music, sound effects only." else ""

        val prompt = """
            你是专业动画导演与分镜师。请严格基于下面已定稿的资产清单，把故事拆解为 6 个连贯镜头。
            统一画风：$style
            已定稿角色：$charInfo
            已定稿场景：$sceneInfo
            已定稿道具：$propInfo
            $silentRule

            请严格只输出一个 JSON 对象，格式如下：
            {
              "shots": [
                {
                  "title": "镜头简短标题（中文）",
                  "description": "这一镜的中文画面与动作说明",
                  "sceneName": "使用的场景中文名",
                  "characterNames": ["出场的角色中文名"],
                  "firstFramePrompt": "Detailed English image generation prompt for the FIRST FRAME of this shot, including camera shot type, exact character appearance, scene, pose, and style",
                  "motionPrompt": "Detailed English video motion prompt describing how the camera and characters move over 6 seconds",
                  "durationSec": 6
                }
              ]
            }

            故事内容：
            $story
        """.trimIndent()

        val raw = callTextLlm(cfg, prompt)
        val json = extractJsonObject(raw)
        val arr = json.optJSONArray("shots") ?: error("AI 未返回 shots 分镜数组")
        val list = mutableListOf<PlannedShot>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = obj.optString("title", "镜头 ${i + 1}").trim()
            val desc = obj.optString("description", "").trim()
            val sceneName = obj.optString("sceneName", "").trim()
            val cArr = obj.optJSONArray("characterNames")
            val charNames = mutableListOf<String>()
            if (cArr != null) {
                for (j in 0 until cArr.length()) {
                    val cn = cArr.optString(j, "").trim()
                    if (cn.isNotBlank()) charNames += cn
                }
            }
            val ff = obj.optString("firstFramePrompt", "$title, $desc").trim()
            val mp = obj.optString("motionPrompt", "subtle 2D animation").trim()
            val durSec = obj.optDouble("durationSec", 6.0).coerceIn(1.0, 15.0)
            list += PlannedShot(
                title = title,
                description = desc,
                sceneName = sceneName,
                characterNames = charNames,
                firstFramePrompt = ff,
                motionPrompt = mp,
                durationMs = (durSec * 1000.0).toLong()
            )
        }
        list
    }

    suspend fun generateImageBytes(
        cfg: AiConfig,
        prompt: String,
        style: String,
        referenceImagePaths: List<String> = emptyList()
    ): ByteArray = withContext(Dispatchers.IO) {
        require(cfg.imageApiKey.isNotBlank()) { "请先在右上角「AI设置」中填写生图 API Key" }
        val base = cfg.imageBaseUrl.trimEnd('/')
        val url = "$base/images/generations"
        val fullPrompt = "Style: $style. $prompt"
        val validRefs = referenceImagePaths.filter { it.isNotBlank() && File(it).exists() }.take(3)
        val headers = mapOf("Authorization" to "Bearer ${cfg.imageApiKey.trim()}")

        fun buildBody(includeRefs: Boolean): String = JSONObject().apply {
            put("model", cfg.imageModel.trim())
            put("prompt", fullPrompt)
            put("size", "1024x1024")
            put("image_size", "1280x720")
            put("n", 1)
            if (includeRefs && validRefs.isNotEmpty()) {
                validRefs.forEachIndexed { idx, path ->
                    val b64 = Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
                    val key = if (idx == 0) "image" else "image${idx + 1}"
                    put(key, "data:image/png;base64,$b64")
                }
            }
        }.toString()

        val resp = if (validRefs.isNotEmpty()) {
            try {
                requestJson("POST", url, buildBody(true), headers)
            } catch (e: Exception) {
                requestJson("POST", url, buildBody(false), headers)
            }
        } else {
            requestJson("POST", url, buildBody(false), headers)
        }
        val json = JSONObject(resp)
        val item = json.optJSONArray("images")?.optJSONObject(0)
            ?: json.optJSONArray("data")?.optJSONObject(0)
            ?: error("生图接口未返回图片数据")
        val b64 = item.optString("b64_json", "")
        if (b64.isNotBlank()) {
            Base64.decode(b64, Base64.DEFAULT)
        } else {
            val imgUrl = item.optString("url", "")
            require(imgUrl.isNotBlank()) { "生图接口未返回图片 URL 或 Base64" }
            downloadBytes(imgUrl)
        }
    }

    suspend fun generateVideoBytes(
        cfg: AiConfig,
        prompt: String,
        firstFramePath: String?,
        referenceImagePaths: List<String> = emptyList()
    ): ByteArray = withContext(Dispatchers.IO) {
        require(cfg.videoApiKey.isNotBlank()) { "请先在右上角「AI设置」中填写视频 API Key" }
        val base = cfg.videoBaseUrl.trimEnd('/')
        val silentSuffix = if (cfg.silentMode) ", silent animation, no background music, crisp sound effects only" else ""
        val body = JSONObject().apply {
            put("model", cfg.videoModel.trim())
            put("prompt", "$prompt$silentSuffix")
            val primaryImg = firstFramePath?.takeIf { it.isNotBlank() && File(it).exists() }
                ?: referenceImagePaths.firstOrNull { it.isNotBlank() && File(it).exists() }
            if (primaryImg != null) {
                val b64 = Base64.encodeToString(File(primaryImg).readBytes(), Base64.NO_WRAP)
                put("image", "data:image/png;base64,$b64")
            }
        }
        val headers = mapOf("Authorization" to "Bearer ${cfg.videoApiKey.trim()}")
        val submitResp = requestJson("POST", "$base/video/submit", body.toString(), headers)
        val submitJson = JSONObject(submitResp)
        val requestId = submitJson.optString("requestId", submitJson.optString("id", ""))
        require(requestId.isNotBlank()) { "视频任务提交失败：$submitResp" }

        repeat(45) {
            delay(4000L)
            val statusBody = JSONObject().apply { put("requestId", requestId) }.toString()
            val statusResp = requestJson("POST", "$base/video/status", statusBody, headers)
            val statusJson = JSONObject(statusResp)
            val status = statusJson.optString("status", "")
            if (status.equals("Succeed", true) || status.equals("SUCCEEDED", true) || status.equals("completed", true)) {
                val results = statusJson.optJSONObject("results")
                val videoUrl = results?.optJSONArray("videos")?.optJSONObject(0)?.optString("url", "")
                    ?: statusJson.optString("video_url", "")
                require(videoUrl.isNotBlank()) { "任务完成但未返回视频地址" }
                return@withContext downloadBytes(videoUrl)
            }
            if (status.equals("Failed", true) || status.equals("FAILED", true)) {
                error("视频生成失败：${statusJson.optString("reason", statusResp)}")
            }
        }
        error("视频生成超时，请稍后重试")
    }

    private suspend fun callTextLlm(cfg: AiConfig, prompt: String): String = withContext(Dispatchers.IO) {
        require(cfg.textApiKey.isNotBlank()) { "请先在右上角「AI设置」中填写文本 API Key" }
        val base = cfg.textBaseUrl.trimEnd('/')
        val url = "$base/chat/completions"
        val body = JSONObject().apply {
            put("model", cfg.textModel.trim())
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            }))
        }
        val headers = mapOf("Authorization" to "Bearer ${cfg.textApiKey.trim()}")
        val resp = requestJson("POST", url, body.toString(), headers)
        val json = JSONObject(resp)
        val content = json.getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
        content.replace(Regex("""<think>[\s\S]*?</think>"""), "").trim()
    }

    private fun extractJsonObject(raw: String): JSONObject {
        val cleaned = raw.replace("```json", "").replace("```", "").trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) { "AI 返回格式不是有效的 JSON：${cleaned.take(120)}" }
        return JSONObject(cleaned.substring(start, end + 1))
    }

    private fun requestJson(method: String, urlStr: String, body: String?, headers: Map<String, String>): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 90_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null) doOutput = true
        }
        if (body != null) {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) error("HTTP $code: ${text.take(240)}")
        return text
    }

    private fun downloadBytes(urlStr: String): ByteArray {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
        }
        return conn.inputStream.use { it.readBytes() }
    }
}
