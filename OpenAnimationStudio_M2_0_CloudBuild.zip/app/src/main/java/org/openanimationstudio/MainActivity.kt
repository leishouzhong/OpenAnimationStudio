package org.openanimationstudio

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.openanimationstudio.data.*
import org.openanimationstudio.ui.LocalAssetPreview
import org.openanimationstudio.ui.TimelineTabContent
import java.io.File
import java.util.UUID

private val StudioDarkColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF0E0D16),
    primaryContainer = Color(0xFF332D66),
    secondary = Color(0xFF4DD0E1),
    background = Color(0xFF101218),
    surface = Color(0xFF181B23),
    surfaceVariant = Color(0xFF232733),
    onBackground = Color(0xFFECEEF4),
    onSurface = Color(0xFFECEEF4)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = WorkspaceRepository(AppDatabase.get(this).dao())
        setContent {
            MaterialTheme(colorScheme = StudioDarkColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    StudioApp(repo)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudioApp(repo: WorkspaceRepository) {
    val context = LocalContext.current
    val activity = context as? Activity
    var isLandscape by remember { mutableStateOf(false) }
    val vm: StudioViewModel = viewModel(factory = StudioViewModel.Factory(repo))
    val projects by vm.projects.collectAsStateWithLifecycle(initialValue = emptyList())
    var activeProject by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    fun toggleOrientation() {
        isLandscape = !isLandscape
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    if (activeProject == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Open Animation Studio") },
                    actions = {
                        IconButton(onClick = { toggleOrientation() }) {
                            Icon(Icons.Filled.ScreenRotation, contentDescription = "切换横竖屏")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null) }
            }
        ) { padding ->
            LazyColumn(Modifier.padding(padding).padding(16.dp)) {
                item { Text("本地动画项目", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(12.dp)) }
                items(projects) { project ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { activeProject = project.id }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(project.name, style = MaterialTheme.typography.titleMedium)
                            Text("画风：${project.visualStyle}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (projects.isEmpty()) item { Text("还没有项目。点击右下角 + 创建你的第一个动画项目。") }
            }
        }
    } else {
        WorkspaceScreen(
            projectId = activeProject!!,
            repo = repo,
            onToggleOrientation = { toggleOrientation() },
            onBack = { activeProject = null }
        )
    }
    if (showCreate) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建项目") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("项目名称") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.create(name); showCreate = false }) { Text("创建") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkspaceScreen(
    projectId: String,
    repo: WorkspaceRepository,
    onToggleOrientation: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val vm: WorkspaceViewModel = viewModel(key = projectId, factory = WorkspaceViewModel.Factory(repo, projectId))
    val shots by vm.shots.collectAsStateWithLifecycle(initialValue = emptyList())
    val characters by vm.characters.collectAsStateWithLifecycle(initialValue = emptyList())
    val scenes by vm.scenes.collectAsStateWithLifecycle(initialValue = emptyList())
    val props by vm.props.collectAsStateWithLifecycle(initialValue = emptyList())

    var step by remember { mutableIntStateOf(0) }
    var storyInput by remember { mutableStateOf("") }
    var visualStyle by remember { mutableStateOf("极简2D死鱼眼线稿（黑线白底、冷幽默）") }
    var isBusy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var aiConfig by remember { mutableStateOf(AiSettingsStore.load(context)) }
    var showAiSettings by remember { mutableStateOf(false) }

    var pendingAssetPick by remember { mutableStateOf<Pair<String, String?>?>(null) } // ("char_replace"|"char_new"|"scene_replace"|"scene_new"|"prop_replace"|"prop_new"|"shot_first", id)
    var pendingVideoShotId by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var editShotTarget by remember { mutableStateOf<ShotEntity?>(null) }

    val assetStore = remember(context, projectId) {
        AssetStore(File(context.filesDir, "projects"))
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val task = pendingAssetPick
        pendingAssetPick = null
        if (uri != null && task != null) {
            val (kind, id) = task
            when (kind) {
                "char_replace" -> if (id != null) vm.replaceCharacterImage(id, uri, context.contentResolver, assetStore) { status = it }
                "char_new" -> vm.importCharacter(uri, context.contentResolver, assetStore, "角色 ${characters.size + 1}") { status = it }
                "scene_replace" -> if (id != null) vm.replaceSceneImage(id, uri, context.contentResolver, assetStore) { status = it }
                "scene_new" -> vm.addSceneWithImage("场景 ${scenes.size + 1}", uri, context.contentResolver, assetStore) { status = it }
                "prop_replace" -> if (id != null) vm.replacePropImage(id, uri, context.contentResolver, assetStore) { status = it }
                "prop_new" -> vm.addPropWithImage("道具 ${props.size + 1}", uri, context.contentResolver, assetStore) { status = it }
                "shot_first" -> if (id != null) vm.importKeyframe(uri, context.contentResolver, assetStore, id, true) { status = it }
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val shotId = pendingVideoShotId
        pendingVideoShotId = null
        if (uri != null && shotId != null) {
            vm.importVideoClip(uri, context.contentResolver, assetStore, shotId) { status = it }
        }
    }

    LaunchedEffect(projectId) {
        val proj = vm.loadProject()
        if (proj != null) {
            storyInput = proj.scriptText
            visualStyle = proj.visualStyle
        }
    }

    @Composable
    fun StepContent(modifier: Modifier = Modifier) {
        Column(modifier) {
            if (status.isNotBlank()) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (isBusy) {
                            CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }

            when (step) {
                // ① 立项与筹备
                0 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("第 1 步：定画风 & 输入故事/灵感", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    val presetStyles = listOf(
                        "极简2D死鱼眼线稿（黑线白底、冷幽默）",
                        "黑白日系怪谈漫画风",
                        "扁平矢量卡通（简洁高对比）",
                        "荒诞手绘涂鸦风"
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presetStyles) { s ->
                            FilterChip(
                                selected = visualStyle == s,
                                onClick = { visualStyle = s; vm.saveStyle(s) },
                                label = { Text(s.substringBefore("（")) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = visualStyle,
                        onValueChange = { visualStyle = it; vm.saveStyle(it) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("当前画风描述（可自定义）") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = storyInput,
                        onValueChange = { storyInput = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 300.dp),
                        label = { Text("输入一句话灵感，或粘贴完整故事剧本") },
                        placeholder = { Text("例如：小雷半夜坐末班电车误入如月车站，遇到社恐女鬼……") }
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        enabled = !isBusy && storyInput.isNotBlank(),
                        onClick = {
                            isBusy = true
                            vm.runStep1PrepareAssets(aiConfig, visualStyle, storyInput, assetStore, onProgress = { status = it }) { ok, updatedStory, msg ->
                                isBusy = false
                                if (ok) {
                                    storyInput = updatedStory
                                    step = 1
                                }
                                status = msg
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isBusy) "正在自动筹备资产…" else "一键生成角色、场景与道具 →")
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = { vm.saveScript(storyInput); vm.saveStyle(visualStyle); step = 1 },
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("跳过 AI，直接手动管理资产 →") }
                }

                // ② 资产定稿与替换
                1 -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("第 2 步：资产定稿（可替换自己的小雷/女鬼）", style = MaterialTheme.typography.titleSmall)
                        TextButton(onClick = { pendingAssetPick = "char_new" to null; imagePicker.launch(arrayOf("image/*")) }) { Text("+角色") }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        item { Text("角色（${characters.size}）", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
                        items(characters, key = { it.id }) { character ->
                            val versions by vm.observeVersions(character.id).collectAsStateWithLifecycle(initialValue = emptyList())
                            val activeVer = versions.firstOrNull { it.id == character.activeVersionId } ?: versions.firstOrNull()
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text(character.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { renameTarget = Triple("character", character.id, character.name) }) { Text("改名") }
                                        TextButton(onClick = { vm.deleteCharacter(character.id) }) { Text("删", color = MaterialTheme.colorScheme.error) }
                                    }
                                    if (character.appearance.isNotBlank()) {
                                        Text(character.appearance, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    activeVer?.let { LocalAssetPreview(it.primaryAssetPath, character.name) }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Button(onClick = { pendingAssetPick = "char_replace" to character.id; imagePicker.launch(arrayOf("image/*")) }) {
                                            Text("替换为我的图")
                                        }
                                        OutlinedButton(enabled = !isBusy, onClick = {
                                            isBusy = true
                                            status = "正在重绘角色「${character.name}」…"
                                            vm.aiRedrawCharacter(aiConfig, visualStyle, character, assetStore) { isBusy = false; status = it }
                                        }) { Text("AI重绘") }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("场景（${scenes.size}）", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.weight(1f))
                                TextButton(onClick = { pendingAssetPick = "scene_new" to null; imagePicker.launch(arrayOf("image/*")) }) { Text("+场景") }
                            }
                        }
                        items(scenes, key = { it.id }) { scene ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text(scene.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { renameTarget = Triple("scene", scene.id, scene.name) }) { Text("改名") }
                                        TextButton(onClick = { vm.deleteScene(scene.id) }) { Text("删", color = MaterialTheme.colorScheme.error) }
                                    }
                                    if (scene.notes.isNotBlank()) Text(scene.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    scene.referenceImagePath?.let { LocalAssetPreview(it, scene.name) }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(onClick = { pendingAssetPick = "scene_replace" to scene.id; imagePicker.launch(arrayOf("image/*")) }) { Text("本地替换") }
                                        OutlinedButton(enabled = !isBusy, onClick = {
                                            isBusy = true; status = "正在重绘场景「${scene.name}」…"
                                            vm.aiRedrawScene(aiConfig, visualStyle, scene, assetStore) { isBusy = false; status = it }
                                        }) { Text("AI重绘") }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("道具（${props.size}）", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.weight(1f))
                                TextButton(onClick = { pendingAssetPick = "prop_new" to null; imagePicker.launch(arrayOf("image/*")) }) { Text("+道具") }
                            }
                        }
                        items(props, key = { it.id }) { prop ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text(prop.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { renameTarget = Triple("prop", prop.id, prop.name) }) { Text("改名") }
                                        TextButton(onClick = { vm.deleteProp(prop.id) }) { Text("删", color = MaterialTheme.colorScheme.error) }
                                    }
                                    if (prop.notes.isNotBlank()) Text(prop.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    prop.referenceImagePath?.let { LocalAssetPreview(it, prop.name) }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(onClick = { pendingAssetPick = "prop_replace" to prop.id; imagePicker.launch(arrayOf("image/*")) }) { Text("本地替换") }
                                        OutlinedButton(enabled = !isBusy, onClick = {
                                            isBusy = true; status = "正在重绘道具「${prop.name}」…"
                                            vm.aiRedrawProp(aiConfig, visualStyle, prop, assetStore) { isBusy = false; status = it }
                                        }) { Text("AI重绘") }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = !isBusy,
                        onClick = {
                            isBusy = true
                            status = "正在基于已定稿资产策划分镜与提示词…"
                            vm.runStep2PlanStoryboard(aiConfig, visualStyle, storyInput, characters, scenes, props) { ok, msg ->
                                isBusy = false
                                status = msg
                                if (ok) step = 2
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isBusy) "正在生成分镜与提示词…" else "确认资产，生成分镜与动画提示词 →")
                    }
                }

                // ③ 分镜与出图出片
                2 -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            enabled = !isBusy && shots.isNotEmpty(),
                            onClick = {
                                isBusy = true
                                vm.batchGenerateAllFirstFrames(aiConfig, visualStyle, shots, assetStore, onProgress = { status = it }) {
                                    isBusy = false; status = it
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("一键生成全部分镜首帧") }
                        FilledTonalButton(onClick = { step = 3 }) { Text("去剪辑导出 →") }
                    }
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(shots, key = { it.id }) { shot ->
                            val hasClip = !shot.videoClipPath.isNullOrBlank() && File(shot.videoClipPath).exists()
                            val boundRefs by vm.observeShotReferences(shot.id).collectAsStateWithLifecycle(initialValue = emptyList())
                            val boundNames = boundRefs.mapNotNull { r -> characters.firstOrNull { it.id == r.characterId }?.name }
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(
                                        "镜 ${shot.orderIndex + 1} · ${shot.title}（${"%.1f".format(shot.durationMs / 1000f)}s）" +
                                            if (hasClip) " · 🎬" else "",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    if (shot.sceneName.isNotBlank() || boundNames.isNotEmpty()) {
                                        Text(
                                            "场景：${shot.sceneName.ifBlank { "未指定" }} | 角色：${boundNames.joinToString("、").ifBlank { "无" }}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    if (shot.description.isNotBlank()) Text(shot.description, style = MaterialTheme.typography.bodySmall)
                                    if (shot.firstFramePrompt.isNotBlank()) {
                                        Text("首帧提示词：${shot.firstFramePrompt}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (shot.motionPrompt.isNotBlank()) {
                                        Text("动画提示词：${shot.motionPrompt}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    shot.firstFramePath?.let { LocalAssetPreview(it, "首帧") }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(
                                            enabled = !isBusy,
                                            onClick = {
                                                isBusy = true
                                                status = "正在按分镜提示词生成「${shot.title}」首帧…"
                                                vm.aiGenerateShotFirstFrame(aiConfig, visualStyle, shot, assetStore) { isBusy = false; status = it }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text(if (shot.firstFramePath == null) "生成首帧" else "重画首帧") }
                                        Button(
                                            enabled = !isBusy,
                                            onClick = {
                                                isBusy = true
                                                status = "正在为「${shot.title}」生成动画视频…"
                                                vm.aiGenerateShotVideo(aiConfig, shot, assetStore) { isBusy = false; status = it }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("AI生视频") }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        TextButton(onClick = { editShotTarget = shot }) { Text("改提示词") }
                                        TextButton(onClick = { pendingAssetPick = "shot_first" to shot.id; imagePicker.launch(arrayOf("image/*")) }) { Text("换首帧") }
                                        TextButton(onClick = { pendingVideoShotId = shot.id; videoPicker.launch(arrayOf("video/*")) }) { Text("导视频") }
                                        if (hasClip) {
                                            TextButton(onClick = { vm.extractLastFrameToNext(shot, shots, assetStore) { status = it } }) { Text("截尾帧→下镜") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ④ 剪辑与导出
                else -> TimelineTabContent(
                    shots = shots,
                    assetStore = assetStore,
                    onSaveShot = { vm.saveShot(it) },
                    onMoveShot = { shot, delta -> vm.move(shot, delta, shots) },
                    onExtractLastFrameToNext = { shot -> vm.extractLastFrameToNext(shot, shots, assetStore) { status = it } },
                    onStatus = { status = it }
                )
            }
        }
    }

    if (isLandscape) {
        Row(Modifier.fillMaxSize()) {
            NavigationRail(
                modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()),
                header = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "返回") } }
            ) {
                NavigationRailItem(selected = step == 0, onClick = { step = 0 }, icon = { Icon(Icons.Filled.AutoAwesome, null) }, label = { Text("1.筹备") })
                NavigationRailItem(selected = step == 1, onClick = { step = 1 }, icon = { Icon(Icons.Filled.Collections, null) }, label = { Text("2.资产") })
                NavigationRailItem(selected = step == 2, onClick = { step = 2 }, icon = { Icon(Icons.Filled.ViewCarousel, null) }, label = { Text("3.分镜") })
                NavigationRailItem(selected = step == 3, onClick = { step = 3 }, icon = { Icon(Icons.Filled.Timeline, null) }, label = { Text("4.导出") })
                IconButton(onClick = { showAiSettings = true }) { Icon(Icons.Filled.Settings, contentDescription = "AI设置") }
                IconButton(onClick = onToggleOrientation) { Icon(Icons.Filled.ScreenRotation, contentDescription = "竖屏") }
            }
            StepContent(Modifier.weight(1f).fillMaxHeight())
        }
    } else {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text("动画制片台") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { showAiSettings = true }) { Icon(Icons.Filled.Settings, contentDescription = "AI设置") }
                    IconButton(onClick = onToggleOrientation) { Icon(Icons.Filled.ScreenRotation, contentDescription = "横屏") }
                }
            )
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                TabRow(selectedTabIndex = step) {
                    Tab(step == 0, { step = 0 }, text = { Text("1.筹备") })
                    Tab(step == 1, { step = 1 }, text = { Text("2.资产") })
                    Tab(step == 2, { step = 2 }, text = { Text("3.分镜") })
                    Tab(step == 3, { step = 3 }, text = { Text("4.导出") })
                }
                StepContent(Modifier.fillMaxSize())
            }
        }
    }

    if (showAiSettings) {
        AlertDialog(
            onDismissRequest = { showAiSettings = false },
            title = { Text("通用 AI 接口设置") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("无声动画模式（禁止BGM）", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Switch(checked = aiConfig.silentMode, onCheckedChange = { aiConfig = aiConfig.copy(silentMode = it) })
                    }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text("1. 文本模型（写剧本/拆资产/分镜）", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(aiConfig.textBaseUrl, { aiConfig = aiConfig.copy(textBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("接口地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.textModel, { aiConfig = aiConfig.copy(textModel = it) }, Modifier.fillMaxWidth(), label = { Text("模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.textApiKey, { aiConfig = aiConfig.copy(textApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Text("2. 生图模型（画角色/场景/首帧）", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(aiConfig.imageBaseUrl, { aiConfig = aiConfig.copy(imageBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("生图接口地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.imageModel, { aiConfig = aiConfig.copy(imageModel = it) }, Modifier.fillMaxWidth(), label = { Text("生图模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.imageApiKey, { aiConfig = aiConfig.copy(imageApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("生图 API Key") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Text("3. 视频模型（可选）", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(aiConfig.videoBaseUrl, { aiConfig = aiConfig.copy(videoBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("视频接口地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.videoModel, { aiConfig = aiConfig.copy(videoModel = it) }, Modifier.fillMaxWidth(), label = { Text("视频模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.videoApiKey, { aiConfig = aiConfig.copy(videoApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("视频 API Key") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    AiSettingsStore.save(context, aiConfig)
                    showAiSettings = false
                    isBusy = true
                    status = "正在测试连接…"
                    vm.testConnection(aiConfig) { status = it; isBusy = false }
                }) { Text("保存并测试") }
            },
            dismissButton = {
                TextButton(onClick = {
                    AiSettingsStore.save(context, aiConfig)
                    showAiSettings = false
                    status = "AI 配置已保存"
                }) { Text("仅保存") }
            }
        )
    }

    editShotTarget?.let { target ->
        var titleEdit by remember(target.id) { mutableStateOf(target.title) }
        var ffEdit by remember(target.id) { mutableStateOf(target.firstFramePrompt) }
        var mpEdit by remember(target.id) { mutableStateOf(target.motionPrompt) }
        AlertDialog(
            onDismissRequest = { editShotTarget = null },
            title = { Text("修改分镜与提示词") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(titleEdit, { titleEdit = it }, label = { Text("镜头标题") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(ffEdit, { ffEdit = it }, label = { Text("首帧生图提示词") }, minLines = 3)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(mpEdit, { mpEdit = it }, label = { Text("动画运动提示词") }, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveShot(target.copy(title = titleEdit.trim().ifBlank { target.title }, firstFramePrompt = ffEdit.trim(), motionPrompt = mpEdit.trim()))
                    status = "已更新「${titleEdit.trim()}」提示词"
                    editShotTarget = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editShotTarget = null }) { Text("取消") } }
        )
    }

    renameTarget?.let { (type, id, oldName) ->
        var newName by remember(id) { mutableStateOf(oldName) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("修改名称") },
            text = { OutlinedTextField(newName, { newName = it }, label = { Text("新名称") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = newName.trim()
                    if (clean.isNotEmpty()) {
                        when (type) {
                            "character" -> vm.renameCharacter(id, clean)
                            "scene" -> vm.renameScene(id, clean)
                            "prop" -> vm.renameProp(id, clean)
                        }
                        status = "已改名为：$clean"
                    }
                    renameTarget = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("取消") } }
        )
    }
}

class StudioViewModel(private val repo: WorkspaceRepository) : ViewModel() {
    val projects = repo.projects()
    fun create(name: String) = viewModelScope.launch { repo.createProject(name) }
    class Factory(private val repo: WorkspaceRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = StudioViewModel(repo) as T
    }
}

class WorkspaceViewModel(private val repo: WorkspaceRepository, private val projectId: String) : ViewModel() {
    val shots = repo.shots(projectId)
    val characters = repo.characters(projectId)
    val scenes = repo.scenes(projectId)
    val props = repo.props(projectId)

    fun observeVersions(characterId: String) = repo.versions(characterId)
    fun observeShotReferences(shotId: String) = repo.observeShotReferences(shotId)
    fun renameCharacter(characterId: String, name: String) = viewModelScope.launch { repo.renameCharacter(characterId, name) }
    fun deleteCharacter(characterId: String) = viewModelScope.launch { repo.deleteCharacter(characterId) }
    fun renameScene(sceneId: String, name: String) = viewModelScope.launch { repo.renameScene(sceneId, name) }
    fun deleteScene(sceneId: String) = viewModelScope.launch { repo.deleteScene(sceneId) }
    fun renameProp(propId: String, name: String) = viewModelScope.launch { repo.renameProp(propId, name) }
    fun deleteProp(propId: String) = viewModelScope.launch { repo.deleteProp(propId) }

    suspend fun loadProject(): ProjectEntity? = repo.getProject(projectId)
    fun saveScript(text: String) = viewModelScope.launch { repo.saveScript(projectId, text) }
    fun saveStyle(style: String) = viewModelScope.launch { repo.saveVisualStyle(projectId, style) }
    fun saveShot(shot: ShotEntity) = viewModelScope.launch { repo.saveShot(shot) }
    fun move(shot: ShotEntity, delta: Int, list: List<ShotEntity>) = viewModelScope.launch {
        val current = list.indexOfFirst { it.id == shot.id }
        val target = current + delta
        if (current < 0 || target !in list.indices) return@launch
        repo.swapShotOrder(list[current], list[target])
    }

    fun testConnection(cfg: AiConfig, done: (String) -> Unit) = viewModelScope.launch {
        runCatching { AiClient.testTextConnection(cfg) }
            .onSuccess { done("连接成功：$it") }
            .onFailure { done("连接失败：${it.message ?: "未知错误"}") }
    }

    fun runStep1PrepareAssets(
        cfg: AiConfig,
        style: String,
        storyOrIdea: String,
        store: AssetStore,
        onProgress: (String) -> Unit,
        done: (Boolean, String, String) -> Unit
    ) = viewModelScope.launch {
        runCatching {
            repo.saveVisualStyle(projectId, style)
            onProgress("正在分析故事并提取角色、场景与道具…")
            val prepared = AiClient.prepareAssetsFromStory(cfg, style, storyOrIdea)
            repo.saveScript(projectId, prepared.story)

            val total = prepared.characters.size + prepared.scenes.size + prepared.props.size
            var idx = 0

            prepared.characters.forEach { item ->
                idx++
                onProgress("正在生成角色「${item.name}」定妆图 ($idx/$total)…")
                val charId = repo.createEmptyCharacter(projectId, item.name, item.prompt)
                runCatching {
                    val bytes = AiClient.generateImageBytes(cfg, item.prompt, style)
                    val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "characters", "png") }
                    repo.addCardVersion(charId, asset)
                }
            }
            prepared.scenes.forEach { item ->
                idx++
                onProgress("正在生成场景「${item.name}」参考图 ($idx/$total)…")
                var path: String? = null
                runCatching {
                    val bytes = AiClient.generateImageBytes(cfg, item.prompt, style)
                    path = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "scenes", "png").absolutePath }
                }
                repo.addSceneFull(projectId, item.name, path, item.prompt)
            }
            prepared.props.forEach { item ->
                idx++
                onProgress("正在生成道具「${item.name}」参考图 ($idx/$total)…")
                var path: String? = null
                runCatching {
                    val bytes = AiClient.generateImageBytes(cfg, item.prompt, style)
                    path = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "props", "png").absolutePath }
                }
                repo.addPropFull(projectId, item.name, path, item.prompt)
            }
            prepared.story
        }.onSuccess { updatedStory ->
            done(true, updatedStory, "资产筹备完成！请在下方检查并替换你的小雷/女鬼图")
        }.onFailure { err ->
            done(false, storyOrIdea, "资产筹备失败：${err.message ?: "未知错误"}")
        }
    }

    fun runStep2PlanStoryboard(
        cfg: AiConfig,
        style: String,
        story: String,
        characters: List<CharacterEntity>,
        scenes: List<SceneEntity>,
        props: List<PropEntity>,
        done: (Boolean, String) -> Unit
    ) = viewModelScope.launch {
        runCatching {
            val planned = AiClient.planStoryboardFromAssets(cfg, style, story, characters, scenes, props)
            val entities = planned.mapIndexed { idx, p ->
                ShotEntity(
                    id = UUID.randomUUID().toString(),
                    projectId = projectId,
                    orderIndex = idx,
                    title = p.title,
                    description = p.description,
                    durationMs = p.durationMs,
                    firstFramePrompt = p.firstFramePrompt,
                    motionPrompt = p.motionPrompt,
                    sceneName = p.sceneName
                )
            }
            repo.replaceShotsForProject(projectId, entities)
            planned.forEachIndexed { idx, p ->
                val shotId = entities[idx].id
                p.characterNames.forEach { cn ->
                    val matched = characters.firstOrNull { it.name.contains(cn) || cn.contains(it.name) }
                    val verId = matched?.activeVersionId
                    if (matched != null && verId != null) {
                        repo.bindCharacterVersion(shotId, matched.id, verId)
                    }
                }
            }
            entities.size
        }.onSuccess { count ->
            done(true, "已生成 $count 个专业分镜与提示词！现在可以生成首帧画面")
        }.onFailure { err ->
            done(false, "分镜策划失败：${err.message ?: "未知错误"}")
        }
    }

    fun batchGenerateAllFirstFrames(
        cfg: AiConfig,
        style: String,
        shots: List<ShotEntity>,
        store: AssetStore,
        onProgress: (String) -> Unit,
        done: (String) -> Unit
    ) = viewModelScope.launch {
        var success = 0
        shots.forEachIndexed { idx, shot ->
            onProgress("正在生成第 ${idx + 1}/${shots.size} 镜首帧：${shot.title}…")
            runCatching {
                val prompt = shot.firstFramePrompt.ifBlank { "${shot.title}, ${shot.description}" }
                val bytes = AiClient.generateImageBytes(cfg, prompt, style)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "keyframes", "png") }
                repo.saveShot(shot.copy(firstFramePath = asset.absolutePath))
            }.onSuccess { success++ }
        }
        done("批量出图完成：成功 $success/${shots.size} 镜")
    }

    fun aiGenerateShotFirstFrame(cfg: AiConfig, style: String, shot: ShotEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val prompt = shot.firstFramePrompt.ifBlank { "${shot.title}, ${shot.description}" }
                val bytes = AiClient.generateImageBytes(cfg, prompt, style)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "keyframes", "png") }
                repo.saveShot(shot.copy(firstFramePath = asset.absolutePath))
            }.onSuccess { done("已生成「${shot.title}」首帧") }
             .onFailure { done("出图失败：${it.message ?: "未知错误"}") }
        }

    fun aiGenerateShotVideo(cfg: AiConfig, shot: ShotEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val prompt = shot.motionPrompt.ifBlank { "${shot.title}. ${shot.description}" }
                val bytes = AiClient.generateVideoBytes(cfg, prompt, shot.firstFramePath)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "videos", "mp4") }
                repo.saveShot(shot.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { done("已生成「${shot.title}」视频") }
             .onFailure { done("生成视频失败：${it.message ?: "未知错误"}") }
        }

    fun aiRedrawCharacter(cfg: AiConfig, style: String, character: CharacterEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val bytes = AiClient.generateImageBytes(cfg, character.appearance.ifBlank { character.name }, style)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "characters", "png") }
                repo.addCardVersion(character.id, asset)
            }.onSuccess { done("已重绘角色「${character.name}」") }
             .onFailure { done("重绘失败：${it.message ?: "未知错误"}") }
        }

    fun aiRedrawScene(cfg: AiConfig, style: String, scene: SceneEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val bytes = AiClient.generateImageBytes(cfg, scene.notes.ifBlank { scene.name }, style)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "scenes", "png") }
                repo.updateSceneAsset(scene.id, asset.absolutePath, scene.notes)
            }.onSuccess { done("已重绘场景「${scene.name}」") }
             .onFailure { done("重绘失败：${it.message ?: "未知错误"}") }
        }

    fun aiRedrawProp(cfg: AiConfig, style: String, prop: PropEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val bytes = AiClient.generateImageBytes(cfg, prop.notes.ifBlank { prop.name }, style)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "props", "png") }
                repo.updatePropAsset(prop.id, asset.absolutePath, prop.notes)
            }.onSuccess { done("已重绘道具「${prop.name}」") }
             .onFailure { done("重绘失败：${it.message ?: "未知错误"}") }
        }

    fun replaceCharacterImage(characterId: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.addCardVersion(characterId, asset)
            }.onSuccess { done("已替换为你的本地角色图（旧版本保留）") }
             .onFailure { done("替换失败：${it.message ?: "未知错误"}") }
        }

    fun replaceSceneImage(sceneId: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "scenes")
                repo.updateSceneAsset(sceneId, asset.absolutePath, "")
            }.onSuccess { done("已替换场景图") }
             .onFailure { done("替换失败：${it.message ?: "未知错误"}") }
        }

    fun replacePropImage(propId: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "props")
                repo.updatePropAsset(propId, asset.absolutePath, "")
            }.onSuccess { done("已替换道具图") }
             .onFailure { done("替换失败：${it.message ?: "未知错误"}") }
        }

    fun importCharacter(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, name: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.createCharacter(projectId, name, asset)
            }.onSuccess { done("已新增角色「$name」") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun addSceneWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "scenes")
                repo.addScene(projectId, name, asset.absolutePath)
            }.onSuccess { done("已新增场景「$name」") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun addPropWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "props")
                repo.addProp(projectId, name, asset.absolutePath)
            }.onSuccess { done("已新增道具「$name」") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importKeyframe(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, shotId: String, isFirst: Boolean, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "keyframes")
                val current = repo.getShot(shotId)
                if (current != null) {
                    repo.saveShot(if (isFirst) current.copy(firstFramePath = asset.absolutePath) else current.copy(lastFramePath = asset.absolutePath))
                }
            }.onSuccess { done("首帧图片已更新") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importVideoClip(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, shotId: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "videos")
                val current = repo.getShot(shotId)
                if (current != null) repo.saveShot(current.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { done("视频片段已导入") }
             .onFailure { done("视频导入失败：${it.message ?: "未知错误"}") }
        }

    fun extractLastFrameToNext(shot: ShotEntity, allShots: List<ShotEntity>, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val clip = shot.videoClipPath ?: error("该镜头还没有视频片段")
                val idx = allShots.indexOfFirst { it.id == shot.id }
                val nextShot = allShots.getOrNull(idx + 1) ?: error("已经是最后一镜，后面没有下一镜")
                val frameAsset = withContext(Dispatchers.IO) { store.extractLastFrame(clip, projectId) }
                repo.saveShot(nextShot.copy(firstFramePath = frameAsset.absolutePath))
                nextShot.title
            }.onSuccess { nextTitle -> done("已截取尾帧并设为「$nextTitle」的首帧") }
             .onFailure { done("截取失败：${it.message ?: "未知错误"}") }
        }

    class Factory(private val repo: WorkspaceRepository, private val id: String) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = WorkspaceViewModel(repo, id) as T
    }
}
