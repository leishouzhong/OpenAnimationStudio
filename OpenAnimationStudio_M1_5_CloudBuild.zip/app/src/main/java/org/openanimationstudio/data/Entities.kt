package org.openanimationstudio.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val scriptText: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val name: String,
    val activeVersionId: String? = null,
    val locked: Boolean = false
)

@Entity(tableName = "character_card_versions")
data class CharacterCardVersionEntity(
    @PrimaryKey val id: String,
    val characterId: String,
    val versionNumber: Int,
    val primaryAssetPath: String,
    val checksumSha256: String,
    val createdAt: Long = System.currentTimeMillis(),
    val acceptedByUser: Boolean = true
)

@Entity(tableName = "shots")
data class ShotEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val orderIndex: Int,
    val title: String,
    val description: String = "",
    val durationMs: Long = 6000,
    val status: String = "DRAFT",
    val firstFramePath: String? = null,
    val lastFramePath: String? = null
)

@Entity(tableName = "shot_character_references")
data class ShotCharacterReferenceEntity(
    @PrimaryKey val id: String,
    val shotId: String,
    val characterId: String,
    val cardVersionId: String,
    val assetPathSnapshot: String,
    val checksumSnapshot: String
)

@Entity(tableName = "generation_snapshots")
data class GenerationSnapshotEntity(
    @PrimaryKey val id: String,
    val shotId: String,
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis()
)


@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val name: String,
    val referenceImagePath: String? = null,
    val notes: String = ""
)

@Entity(tableName = "props")
data class PropEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val name: String,
    val referenceImagePath: String? = null,
    val notes: String = ""
)
