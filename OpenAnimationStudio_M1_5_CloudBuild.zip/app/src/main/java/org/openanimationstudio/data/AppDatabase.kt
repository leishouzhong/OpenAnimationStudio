package org.openanimationstudio.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProjectEntity::class, CharacterEntity::class, CharacterCardVersionEntity::class,
        ShotEntity::class, ShotCharacterReferenceEntity::class, GenerationSnapshotEntity::class,
        SceneEntity::class, PropEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `scenes` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS `props` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
            }
        }
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "open_animation_studio.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}
