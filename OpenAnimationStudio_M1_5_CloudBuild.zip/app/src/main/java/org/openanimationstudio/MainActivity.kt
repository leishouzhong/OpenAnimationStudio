package org.openanimationstudio

import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import org.openanimationstudio.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = WorkspaceRepository(AppDatabase.get(this).dao())
        setContent { MaterialTheme { StudioApp(repo) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudioApp(repo: WorkspaceRepository) {
    val vm: StudioViewModel = viewModel(factory = StudioViewModel.Factory(repo))
    val projects by vm.projects.collectAsStateWithLifecycle(initialValue = emptyList())
    var activeProject by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    if (activeProject == null) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Open Animation Studio") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null) }
            }
        ) { padding ->
            LazyColumn(Modifier.padding(padding).padding(16.dp)) {
                item { Text("本地项目", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(12.dp)) }
                items(projects) { project ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { activeProject = project.id }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(project.name, style = MaterialTheme.typography.titleMedium)
                            Text("打开项目工作区", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (projects.isEmpty()) item { Text("还没有项目。点击右下角创建第一个项目。") }
            }
        }
    } else {
        WorkspaceScreen(projectId = activeProject!!, repo = repo, onBack = { activeProject = null })
    }
    if (showCreate) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建项目") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("项目名称") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.create(name); showCreate = false }) { Text("创建") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkspaceScreen(projectId: String, repo: WorkspaceRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val vm: WorkspaceViewModel = viewModel(key = projectId, factory = WorkspaceViewModel.Factory(repo, projectId))
    val shots by vm.shots.collectAsStateWithLifecycle(initialValue = emptyList())
    val characters by vm.characters.collectAsStateWithLifecycle(initialValue = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var newShotTitle by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("") }
    var newCharacterName by remember { mutableStateOf("") }
    var pendingCharacterImport by remember { mutableStateOf(false) }
    var pendingVersionCharacter by remember { mutableStateOf<String?>(null) }
    var pendingKeyframeShot by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var sceneName by remember { mutableStateOf("") }
    var propName by remember { mutableStateOf("") }
    var pendingReferenceImport by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    val assetStore = remember(context, projectId) {
        AssetStore(File(context.filesDir, "projects"))
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            when {
                pendingCharacterImport -> {
                    val name = newCharacterName
                    vm.importCharacter(uri, context.contentResolver, assetStore, name) { result ->
                        status = result
                        newCharacterName = ""
                        pendingCharacterImport = false
                    }
                }
                pendingVersionCharacter != null -> {
                    val characterId = pendingVersionCharacter!!
                    vm.importVersion(uri, context.contentResolver, assetStore, characterId) { result ->
                        status = result
                        pendingVersionCharacter = null
                    }
                }
                pendingKeyframeShot != null -> {
                    val (shotId, isFirst) = pendingKeyframeShot!!
                    vm.importKeyframe(uri, context.contentResolver, assetStore, shotId, isFirst) { result ->
                        status = result
                        pendingKeyframeShot = null
                    }
                }
                pendingReferenceImport == "scene" -> {
                    vm.addSceneWithImage(sceneName, uri, context.contentResolver, assetStore) { result ->
                        status = result
                        sceneName = ""
                        pendingReferenceImport = null
                    }
                }
                pendingReferenceImport == "prop" -> {
                    vm.addPropWithImage(propName, uri, context.contentResolver, assetStore) { result ->
                        status = result
                        propName = ""
                        pendingReferenceImport = null
                    }
                }
            }
        } else {
            pendingCharacterImport = false
            pendingVersionCharacter = null
            pendingKeyframeShot = null
            pendingReferenceImport = null
        }
    }

    LaunchedEffect(projectId) { script = vm.loadScript() }
    Scaffold(topBar = {
        TopAppBar(title = { Text("项目工作区") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        })
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("剧本") })
                Tab(tab == 1, { tab = 1 }, text = { Text("分镜") })
                Tab(tab == 2, { tab = 2 }, text = { Text("角色素材") })
                Tab(tab == 3, { tab = 3 }, text = { Text("场景道具") })
            }
            if (status.isNotBlank()) {
                Text(status, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.primary)
            }
            when (tab) {
                0 -> Column(Modifier.padding(16.dp)) {
                    Text("剧本内容", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = script, onValueChange = { script = it },
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        placeholder = { Text("在这里编写或粘贴剧本……") }
                    )
                    Button(onClick = { vm.saveScript(script); status = "剧本已保存" }, modifier = Modifier.fillMaxWidth()) {
                        Text("保存剧本")
                    }
                }
                1 -> Column(Modifier.padding(16.dp)) {
                    Text("分镜列表 · ${shots.size} 镜", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newShotTitle, onValueChange = { newShotTitle = it },
                            modifier = Modifier.weight(1f), label = { Text("镜头标题") }, singleLine = true
                        )
                        Button(onClick = {
                            if (newShotTitle.isNotBlank()) {
                                vm.addShot(newShotTitle.trim(), shots.size); newShotTitle = ""
                            }
                        }) { Text("添加") }
                    }
                    LazyColumn {
                        items(shots, key = { it.id }) { shot ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("镜头 ${shot.orderIndex + 1} · ${shot.title}", style = MaterialTheme.typography.titleSmall)
                                    Text(shot.description.ifBlank { "尚未填写镜头内容" }, style = MaterialTheme.typography.bodySmall)
                                    Text("首帧：${shot.firstFramePath?.substringAfterLast('/') ?: "未导入"}")
                                    if (shot.firstFramePath != null) LocalAssetPreview(shot.firstFramePath, "首帧预览")
                                    Text("尾帧：${shot.lastFramePath?.substringAfterLast('/') ?: "未导入"}")
                                    if (shot.lastFramePath != null) LocalAssetPreview(shot.lastFramePath, "尾帧预览")
                                    var showBind by remember(shot.id) { mutableStateOf(false) }
                                    TextButton(onClick = { showBind = !showBind }) { Text("绑定角色卡版本") }
                                    if (showBind) {
                                        characters.forEach { character ->
                                            val versions by vm.observeVersions(character.id).collectAsStateWithLifecycle(initialValue = emptyList())
                                            Text(character.name, style = MaterialTheme.typography.labelLarge)
                                            versions.forEach { version ->
                                                TextButton(onClick = {
                                                    vm.bindCharacterVersion(shot.id, character.id, version.id)
                                                    status = "已绑定 ${character.name} 版本 ${version.versionNumber}"
                                                    showBind = false
                                                }) { Text("使用版本 ${version.versionNumber}") }
                                            }
                                        }
                                    }
                                    TextButton(onClick = {
                                        vm.checkAssets(shot.id) { issues ->
                                            status = if (issues.isEmpty()) "镜头素材检查通过" else "素材问题：" + issues.joinToString("、")
                                        }
                                    }) { Text("检查素材") }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(onClick = { vm.move(shot, -1, shots) }) { Text("上移") }
                                        TextButton(onClick = { vm.move(shot, 1, shots) }) { Text("下移") }
                                        TextButton(onClick = { pendingKeyframeShot = shot.id to true; imagePicker.launch(arrayOf("image/*")) }) { Text("导入首帧") }
                                        TextButton(onClick = { pendingKeyframeShot = shot.id to false; imagePicker.launch(arrayOf("image/*")) }) { Text("导入尾帧") }
                                        TextButton(onClick = { vm.delete(shot.id); status = "镜头已删除" }) { Text("删除") }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> Column(Modifier.padding(16.dp)) {
                    Text("角色卡资产", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = newCharacterName, onValueChange = { newCharacterName = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("角色名称") }, singleLine = true
                    )
                    Button(onClick = {
                        pendingCharacterImport = true
                        imagePicker.launch(arrayOf("image/*"))
                    }, modifier = Modifier.fillMaxWidth()) { Text("导入新角色卡") }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn {
                        items(characters, key = { it.id }) { character ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(character.name, style = MaterialTheme.typography.titleSmall)
                                    Text(if (character.locked) "用户锁定" else "未锁定")
                                    val versions by vm.observeVersions(character.id).collectAsStateWithLifecycle(initialValue = emptyList())
                                    versions.firstOrNull { it.id == character.activeVersionId }?.let { active ->
                                        LocalAssetPreview(active.primaryAssetPath, "当前角色卡")
                                    }
                                    versions.forEach { version ->
                                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text("版本 ${version.versionNumber}${if (character.activeVersionId == version.id) " · 当前" else ""}",
                                                modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                            if (character.activeVersionId != version.id) {
                                                TextButton(onClick = { vm.restoreVersion(character.id, version.id); status = "已切换角色卡版本" }) { Text("设为当前") }
                                            }
                                        }
                                    }
                                    Row {
                                        TextButton(onClick = {
                                            pendingVersionCharacter = character.id
                                            imagePicker.launch(arrayOf("image/*"))
                                        }) { Text("导入新版本") }
                                        TextButton(onClick = { vm.setLocked(character.id, !character.locked) }) {
                                            Text(if (character.locked) "解除锁定" else "锁定角色卡")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> Column(Modifier.padding(16.dp)) {
                    Text("场景与道具素材", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(sceneName, { sceneName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("场景名称") })
                    Button(onClick = {
                        if (sceneName.isNotBlank()) { vm.addScene(sceneName); sceneName = ""; status = "场景已添加" }
                    }) { Text("仅添加场景名称") }
                    Button(onClick = {
                        if (sceneName.isNotBlank()) { pendingReferenceImport = "scene"; imagePicker.launch(arrayOf("image/*")) }
                    }) { Text("导入场景卡图片并创建") }
                    val scenes by vm.scenes.collectAsStateWithLifecycle(initialValue = emptyList())
                    scenes.forEach { scene ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Text("场景 · ${scene.name}")
                                scene.referenceImagePath?.let { LocalAssetPreview(it, "场景参考图") }
                            }
                        }
                    }
                    Divider(Modifier.padding(vertical = 8.dp))
                    OutlinedTextField(propName, { propName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("道具名称") })
                    Button(onClick = {
                        if (propName.isNotBlank()) { vm.addProp(propName); propName = ""; status = "道具已添加" }
                    }) { Text("仅添加道具名称") }
                    Button(onClick = {
                        if (propName.isNotBlank()) { pendingReferenceImport = "prop"; imagePicker.launch(arrayOf("image/*")) }
                    }) { Text("导入道具卡图片并创建") }
                    val props by vm.props.collectAsStateWithLifecycle(initialValue = emptyList())
                    props.forEach { prop ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Text("道具 · ${prop.name}")
                                prop.referenceImagePath?.let { LocalAssetPreview(it, "道具参考图") }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun LocalAssetPreview(path: String, description: String) {
    var bitmap by remember(path) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(path) { mutableStateOf(false) }
    LaunchedEffect(path) {
        val decoded = withContext(Dispatchers.IO) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
                var sample = 1
                while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            }
        }
        bitmap = decoded
        failed = decoded == null
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = description,
            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
            contentScale = ContentScale.Fit
        )
    } else if (failed) {
        Text("图片无法预览：文件可能损坏或格式不支持", color = MaterialTheme.colorScheme.error)
    } else {
        Text("正在读取图片…", style = MaterialTheme.typography.bodySmall)
    }
}

class StudioViewModel(private val repo: WorkspaceRepository) : ViewModel() {
    val projects = repo.projects()
    fun create(name: String) = viewModelScope.launch { repo.createProject(name) }
    class Factory(private val repo: WorkspaceRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = StudioViewModel(repo) as T
    }
}

class WorkspaceViewModel(private val repo: WorkspaceRepository, private val projectId: String) : ViewModel() {
    val shots = repo.shots(projectId)
    val characters = repo.characters(projectId)
    val scenes = repo.scenes(projectId)
    val props = repo.props(projectId)
    fun observeVersions(characterId: String) = repo.versions(characterId)
    fun restoreVersion(characterId: String, versionId: String) = viewModelScope.launch { repo.restoreVersion(characterId, versionId) }
    fun bindCharacterVersion(shotId: String, characterId: String, versionId: String) = viewModelScope.launch {
        repo.bindCharacterVersion(shotId, characterId, versionId)
    }
    fun addScene(name: String) = viewModelScope.launch { repo.addScene(projectId, name) }
    fun addProp(name: String) = viewModelScope.launch { repo.addProp(projectId, name) }
    fun addSceneWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                require(name.isNotBlank()) { "请先填写场景名称" }
                val asset = store.importUri(resolver, uri, projectId, "scenes")
                repo.addScene(projectId, name, asset.absolutePath)
            }.onSuccess { done("场景卡图片已导入") }
             .onFailure { done("场景图片导入失败：${it.message ?: "未知错误"}") }
        }
    fun addPropWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                require(name.isNotBlank()) { "请先填写道具名称" }
                val asset = store.importUri(resolver, uri, projectId, "props")
                repo.addProp(projectId, name, asset.absolutePath)
            }.onSuccess { done("道具卡图片已导入") }
             .onFailure { done("道具图片导入失败：${it.message ?: "未知错误"}") }
        }
    fun checkAssets(shotId: String, done: (List<String>) -> Unit) = viewModelScope.launch { done(repo.checkShotAssets(shotId)) }
    suspend fun loadScript(): String = repo.getProject(projectId)?.scriptText.orEmpty()
    fun saveScript(text: String) = viewModelScope.launch { repo.saveScript(projectId, text) }
    fun addShot(title: String, index: Int) = viewModelScope.launch { repo.appendShot(projectId, index, title, "") }
    fun delete(id: String) = viewModelScope.launch { repo.deleteShot(id, projectId) }
    fun move(shot: ShotEntity, delta: Int, list: List<ShotEntity>) = viewModelScope.launch {
        val current = list.indexOfFirst { it.id == shot.id }
        val target = current + delta
        if (current < 0 || target !in list.indices) return@launch
        repo.swapShotOrder(list[current], list[target])
    }
    fun setLocked(characterId: String, locked: Boolean) = viewModelScope.launch { repo.setLocked(characterId, locked) }

    fun importCharacter(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, name: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.createCharacter(projectId, name, asset)
            }.onSuccess { done("角色卡已导入，已创建第 1 个版本") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importVersion(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, characterId: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.addCardVersion(characterId, asset)
            }.onSuccess { done("新角色卡版本已保存，旧版本保留") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importKeyframe(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, shotId: String, isFirst: Boolean, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "keyframes")
                val current = repo.getShot(shotId)
                if (current != null) {
                    repo.saveShot(if (isFirst) current.copy(firstFramePath = asset.absolutePath)
                    else current.copy(lastFramePath = asset.absolutePath))
                }
            }.onSuccess { done(if (isFirst) "首帧图片已导入" else "尾帧图片已导入") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    class Factory(private val repo: WorkspaceRepository, private val id: String) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = WorkspaceViewModel(repo, id) as T
    }
}
