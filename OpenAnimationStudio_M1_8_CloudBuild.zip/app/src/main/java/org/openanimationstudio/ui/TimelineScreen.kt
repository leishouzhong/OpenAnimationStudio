package org.openanimationstudio.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.openanimationstudio.data.AssetStore
import org.openanimationstudio.data.ShotEntity
import org.openanimationstudio.export.Mp4Exporter
import java.io.File
import kotlin.math.roundToInt

@Composable
fun TimelineTabContent(
    shots: List<ShotEntity>,
    assetStore: AssetStore,
    onSaveShot: (ShotEntity) -> Unit,
    onMoveShot: (ShotEntity, Int) -> Unit,
    onExtractLastFrameToNext: (ShotEntity) -> Unit,
    onStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }

    if (shots.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("暂无分镜镜头", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("请先在「剧本」页生成或拆解分镜，或在「分镜」页添加镜头。", style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    var selectedShotId by remember { mutableStateOf(shots.first().id) }
    LaunchedEffect(shots) {
        if (shots.none { it.id == selectedShotId }) {
            selectedShotId = shots.first().id
        }
    }

    var isPlaying by remember { mutableStateOf(false) }
    var playIndex by remember { mutableIntStateOf(0) }
    var shotElapsedMs by remember { mutableLongStateOf(0L) }
    var audioTriggeredForShotId by remember { mutableStateOf<String?>(null) }
    val mediaPlayerHolder = remember { mutableStateOf<MediaPlayer?>(null) }

    fun stopAudio() {
        runCatching {
            mediaPlayerHolder.value?.apply {
                if (isPlaying) stop()
                release()
            }
        }
        mediaPlayerHolder.value = null
    }

    DisposableEffect(Unit) {
        onDispose { stopAudio() }
    }

    LaunchedEffect(isPlaying, shots) {
        if (!isPlaying) {
            stopAudio()
            audioTriggeredForShotId = null
            return@LaunchedEffect
        }
        var lastTick = System.nanoTime()
        while (isPlaying && shots.isNotEmpty()) {
            delay(16L)
            val now = System.nanoTime()
            val dtMs = ((now - lastTick) / 1_000_000L).coerceIn(1L, 100L)
            lastTick = now

            val current = shots.getOrNull(playIndex) ?: break
            val dur = current.durationMs.coerceAtLeast(500L)

            if (!current.audioPath.isNullOrBlank() && audioTriggeredForShotId != current.id && shotElapsedMs >= current.audioStartMs) {
                audioTriggeredForShotId = current.id
                stopAudio()
                runCatching {
                    MediaPlayer().apply {
                        setDataSource(current.audioPath)
                        prepare()
                        start()
                        mediaPlayerHolder.value = this
                    }
                }
            }

            shotElapsedMs += dtMs
            if (shotElapsedMs >= dur) {
                stopAudio()
                audioTriggeredForShotId = null
                if (playIndex + 1 < shots.size) {
                    playIndex += 1
                    shotElapsedMs = 0L
                    selectedShotId = shots[playIndex].id
                } else {
                    isPlaying = false
                    playIndex = 0
                    shotElapsedMs = 0L
                    selectedShotId = shots.first().id
                }
            }
        }
    }

    val activeShot = if (isPlaying) shots.getOrNull(playIndex) ?: shots.first()
    else shots.firstOrNull { it.id == selectedShotId } ?: shots.first()

    val totalDurationMs = shots.sumOf { it.durationMs.coerceAtLeast(500L) }
    val currentTimelineMs = if (isPlaying) {
        shots.take(playIndex).sumOf { it.durationMs.coerceAtLeast(500L) } + shotElapsedMs
    } else 0L

    var firstBitmap by remember(activeShot.firstFramePath) { mutableStateOf<Bitmap?>(null) }
    var lastBitmap by remember(activeShot.lastFramePath) { mutableStateOf<Bitmap?>(null) }
    var videoThumb by remember(activeShot.videoClipPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(activeShot.firstFramePath) {
        firstBitmap = activeShot.firstFramePath?.let { decodeSampledBitmap(it, 960) }
    }
    LaunchedEffect(activeShot.lastFramePath) {
        lastBitmap = activeShot.lastFramePath?.let { decodeSampledBitmap(it, 960) }
    }
    LaunchedEffect(activeShot.videoClipPath) {
        videoThumb = activeShot.videoClipPath?.let { path ->
            withContext(Dispatchers.IO) {
                runCatching {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(path)
                    val b = r.getFrameAtTime(0L)
                    r.release()
                    b
                }.getOrNull()
            }
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val asset = assetStore.importUri(context.contentResolver, uri, activeShot.projectId, "audio")
                onSaveShot(activeShot.copy(audioPath = asset.absolutePath))
            }.onSuccess { onStatus("音效已导入：${activeShot.title}") }
                .onFailure { onStatus("音效导入失败：${it.message ?: "未知错误"}") }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val asset = assetStore.importUri(context.contentResolver, uri, activeShot.projectId, "videos")
                onSaveShot(activeShot.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { onStatus("视频片段已导入：${activeShot.title}") }
                .onFailure { onStatus("视频导入失败：${it.message ?: "未知错误"}") }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        val dur = activeShot.durationMs.coerceAtLeast(500L).toFloat()
        val progress = if (isPlaying) (shotElapsedMs / dur).coerceIn(0f, 1f) else 0f
        val hasVideo = !activeShot.videoClipPath.isNullOrBlank() && File(activeShot.videoClipPath).exists()

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0E1015))
                .clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
            val showBmp = if (hasVideo) (videoThumb ?: firstBitmap) else {
                if (firstBitmap != null && lastBitmap != null && progress > 0.5f) lastBitmap else (firstBitmap ?: lastBitmap)
            }
            if (showBmp != null) {
                Image(
                    bitmap = showBmp.asImageBitmap(),
                    contentDescription = activeShot.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        if (!hasVideo && isPlaying) {
                            val s = activeShot.startScale + (activeShot.endScale - activeShot.startScale) * progress
                            scaleX = s
                            scaleY = s
                        }
                    }
                )
            } else {
                Text("当前镜头尚未导入视频或首/尾帧", color = Color(0xFF8C91A0))
            }

            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            ) {
                Text(
                    text = "镜 ${activeShot.orderIndex + 1} · ${activeShot.title}" + if (hasVideo) " · 🎬真视频" else "",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = {
                    if (!isPlaying) {
                        playIndex = shots.indexOfFirst { it.id == selectedShotId }.coerceAtLeast(0)
                        shotElapsedMs = 0L
                        audioTriggeredForShotId = null
                    }
                    isPlaying = !isPlaying
                }) {
                    Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (isPlaying) "暂停" else "预览")
                }
                IconButton(onClick = {
                    isPlaying = false
                    playIndex = 0
                    shotElapsedMs = 0L
                    selectedShotId = shots.first().id
                }) {
                    Icon(Icons.Filled.Replay, contentDescription = "从头开始")
                }
                Button(
                    enabled = !isExporting,
                    onClick = {
                        isPlaying = false
                        isExporting = true
                        exportProgress = 0f
                        scope.launch {
                            runCatching {
                                Mp4Exporter.exportShotsToMp4(context, shots, "OpenAnimation") { p ->
                                    exportProgress = p
                                }
                            }.onSuccess { msg ->
                                isExporting = false
                                onStatus(msg)
                            }.onFailure { err ->
                                isExporting = false
                                onStatus("导出 MP4 失败：${err.message ?: "未知错误"}")
                            }
                        }
                    }
                ) {
                    Text(if (isExporting) "导出 ${(exportProgress * 100).toInt()}%" else "导出 MP4")
                }
            }
            Text(
                text = "${formatMs(currentTimelineMs)}/${formatMs(totalDurationMs)}",
                style = MaterialTheme.typography.labelMedium
            )
        }

        Text("时间轴（点击镜头管理视频与音效）", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(shots, key = { _, s -> s.id }) { idx, shot ->
                val isSelected = shot.id == activeShot.id
                val clipReady = !shot.videoClipPath.isNullOrBlank()
                val widthDp = ((shot.durationMs / 1000f) * 20f).coerceIn(96f, 220f).dp
                Card(
                    modifier = Modifier
                        .width(widthDp)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            isPlaying = false
                            selectedShotId = shot.id
                            playIndex = idx
                            shotElapsedMs = 0L
                        }
                ) {
                    Column(Modifier.padding(8.dp)) {
                        Text("${idx + 1}. ${shot.title}", maxLines = 1, style = MaterialTheme.typography.labelLarge)
                        Text(
                            "${"%.1f".format(shot.durationMs / 1000f)}s" +
                                (if (clipReady) " · 🎬" else "") +
                                (if (!shot.audioPath.isNullOrBlank()) " · ♫" else ""),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            IconButton(onClick = { onMoveShot(shot, -1) }, enabled = idx > 0, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.ArrowBack, contentDescription = "前移", modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { onMoveShot(shot, 1) }, enabled = idx < shots.lastIndex, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.ArrowForward, contentDescription = "后移", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider()
        Spacer(Modifier.height(12.dp))

        var durationSec by remember(activeShot.id, activeShot.durationMs) { mutableFloatStateOf(activeShot.durationMs / 1000f) }
        var muteOriginal by remember(activeShot.id, activeShot.muteOriginalAudio) { mutableStateOf(activeShot.muteOriginalAudio) }
        var audioStartSec by remember(activeShot.id, activeShot.audioStartMs) { mutableFloatStateOf(activeShot.audioStartMs / 1000f) }

        Text("镜头控制台 · ${activeShot.title}", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { videoPicker.launch(arrayOf("video/*")) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Filled.Movie, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (hasVideo) "更换视频片段" else "导入视频片段")
            }
            if (hasVideo) {
                Button(
                    onClick = { onExtractLastFrameToNext(activeShot) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("截尾帧→下镜首帧")
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("静音原片声音（只留自选音效）", style = MaterialTheme.typography.bodyMedium)
                Text("导出时自动剥离 AI 视频自带的背景音乐", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked = muteOriginal,
                onCheckedChange = {
                    muteOriginal = it
                    onSaveShot(activeShot.copy(muteOriginalAudio = it))
                }
            )
        }

        Spacer(Modifier.height(6.dp))
        ParamSlider("镜头时长（默认 6.0 秒）", "${"%.1f".format(durationSec)} 秒", durationSec, 1f..15f) {
            durationSec = (it * 2f).roundToInt() / 2f
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) {
                Icon(Icons.Filled.Audiotrack, null)
                Spacer(Modifier.width(4.dp))
                Text(if (activeShot.audioPath.isNullOrBlank()) "导入干净音效" else "更换音效")
            }
            if (!activeShot.audioPath.isNullOrBlank()) {
                Text("已绑定音效", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    onSaveShot(activeShot.copy(audioPath = null, audioStartMs = 0L))
                    onStatus("已移除音效")
                }) {
                    Icon(Icons.Filled.Delete, contentDescription = "清除音效")
                }
            }
        }
        if (!activeShot.audioPath.isNullOrBlank()) {
            ParamSlider("音效起始位置", "${"%.1f".format(audioStartSec)} 秒", audioStartSec, 0f..durationSec) {
                audioStartSec = (it * 2f).roundToInt() / 2f
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                onSaveShot(
                    activeShot.copy(
                        durationMs = (durationSec * 1000f).toLong().coerceAtLeast(500L),
                        muteOriginalAudio = muteOriginal,
                        audioStartMs = (audioStartSec * 1000f).toLong()
                    )
                )
                onStatus("已保存「${activeShot.title}」的镜头设置")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("保存当前镜头设置")
        }
    }
}

@Composable
private fun ParamSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(valueText, style = MaterialTheme.typography.labelMedium)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range)
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%02d:%02d".format(min, sec)
}
