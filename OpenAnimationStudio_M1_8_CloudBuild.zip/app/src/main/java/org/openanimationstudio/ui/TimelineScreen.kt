package org.openanimationstudio.ui

import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.openanimationstudio.data.AssetStore
import org.openanimationstudio.data.ShotEntity
import org.openanimationstudio.export.Mp4Exporter
import java.io.File
import kotlin.math.roundToInt

@Composable
fun TimelineTabContent(
    shots: List<ShotEntity>,
    assetStore: AssetStore,
    onSaveShot: (ShotEntity) -> Unit,
    onMoveShot: (ShotEntity, Int) -> Unit,
    onExtractLastFrameToNext: (ShotEntity) -> Unit,
    onStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val scope = rememberCoroutineScope()
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }

    if (shots.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("暂无分镜镜头", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("请先在「剧本」页生成或拆解分镜，或在「分镜」页添加镜头。", style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    var selectedShotId by remember { mutableStateOf(shots.first().id) }
    LaunchedEffect(shots) {
        if (shots.none { it.id == selectedShotId }) selectedShotId = shots.first().id
    }

    var isPlaying by remember { mutableStateOf(false) }
    var playIndex by remember { mutableIntStateOf(0) }
    var shotElapsedMs by remember { mutableLongStateOf(0L) }
    var audioTriggeredForShotId by remember { mutableStateOf<String?>(null) }
    val mediaPlayerHolder = remember { mutableStateOf<MediaPlayer?>(null) }

    fun stopAudio() {
        runCatching {
            mediaPlayerHolder.value?.apply {
                if (isPlaying) stop()
                release()
            }
        }
        mediaPlayerHolder.value = null
    }

    DisposableEffect(Unit) { onDispose { stopAudio() } }

    LaunchedEffect(isPlaying, shots) {
        if (!isPlaying) {
            stopAudio()
            audioTriggeredForShotId = null
            return@LaunchedEffect
        }
        var lastTick = System.nanoTime()
        while (isPlaying && shots.isNotEmpty()) {
            delay(16L)
            val now = System.nanoTime()
            val dtMs = ((now - lastTick) / 1_000_000L).coerceIn(1L, 100L)
            lastTick = now

            val current = shots.getOrNull(playIndex) ?: break
            val dur = current.durationMs.coerceAtLeast(500L)

            if (!current.audioPath.isNullOrBlank() && audioTriggeredForShotId != current.id && shotElapsedMs >= current.audioStartMs) {
                audioTriggeredForShotId = current.id
                stopAudio()
                runCatching {
                    MediaPlayer().apply {
                        setDataSource(current.audioPath)
                        prepare()
                        start()
                        mediaPlayerHolder.value = this
                    }
                }
            }

            shotElapsedMs += dtMs
            if (shotElapsedMs >= dur) {
                stopAudio()
                audioTriggeredForShotId = null
                if (playIndex + 1 < shots.size) {
                    playIndex += 1
                    shotElapsedMs = 0L
                    selectedShotId = shots[playIndex].id
                } else {
                    isPlaying = false
                    playIndex = 0
                    shotElapsedMs = 0L
                    selectedShotId = shots.first().id
                }
            }
        }
    }

    val activeShot = if (isPlaying) shots.getOrNull(playIndex) ?: shots.first()
    else shots.firstOrNull { it.id == selectedShotId } ?: shots.first()

    val totalDurationMs = shots.sumOf { it.durationMs.coerceAtLeast(500L) }
    val currentTimelineMs = if (isPlaying) {
        shots.take(playIndex).sumOf { it.durationMs.coerceAtLeast(500L) } + shotElapsedMs
    } else 0L

    var firstBitmap by remember(activeShot.firstFramePath) { mutableStateOf<Bitmap?>(null) }
    var lastBitmap by remember(activeShot.lastFramePath) { mutableStateOf<Bitmap?>(null) }
    var videoThumb by remember(activeShot.videoClipPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(activeShot.firstFramePath) {
        firstBitmap = activeShot.firstFramePath?.let { decodeSampledBitmap(it, 960) }
    }
    LaunchedEffect(activeShot.lastFramePath) {
        lastBitmap = activeShot.lastFramePath?.let { decodeSampledBitmap(it, 960) }
    }
    LaunchedEffect(activeShot.videoClipPath) {
        videoThumb = activeShot.videoClipPath?.let { path ->
            withContext(Dispatchers.IO) {
                runCatching {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(path)
                    val b = r.getFrameAtTime(0L)
                    r.release()
                    b
                }.getOrNull()
            }
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val asset = assetStore.importUri(context.contentResolver, uri, activeShot.projectId, "audio")
                onSaveShot(activeShot.copy(audioPath = asset.absolutePath))
            }.onSuccess { onStatus("音效已导入：${activeShot.title}") }
                .onFailure { onStatus("音效导入失败：${it.message ?: "未知错误"}") }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val asset = assetStore.importUri(context.contentResolver, uri, activeShot.projectId, "videos")
                onSaveShot(activeShot.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { onStatus("视频片段已导入：${activeShot.title}") }
                .onFailure { onStatus("视频导入失败：${it.message ?: "未知错误"}") }
        }
    }

    val hasVideo = !activeShot.videoClipPath.isNullOrBlank() && File(activeShot.videoClipPath).exists()
    val dur = activeShot.durationMs.coerceAtLeast(500L).toFloat()
    val progress = if (isPlaying) (shotElapsedMs / dur).coerceIn(0f, 1f) else 0f

    @Composable
    fun PreviewAndControls(modifier: Modifier = Modifier) {
        Column(modifier) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0E1015))
                    .clipToBounds(),
                contentAlignment = Alignment.Center
            ) {
                val showBmp = if (hasVideo) (videoThumb ?: firstBitmap) else {
                    if (firstBitmap != null && lastBitmap != null && progress > 0.5f) lastBitmap else (firstBitmap ?: lastBitmap)
                }
                if (showBmp != null) {
                    Image(
                        bitmap = showBmp.asImageBitmap(),
                        contentDescription = activeShot.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            if (!hasVideo && isPlaying) {
                                val s = activeShot.startScale + (activeShot.endScale - activeShot.startScale) * progress
                                scaleX = s; scaleY = s
                            }
                        }
                    )
                } else {
                    Text("尚未导入视频或首/尾帧", color = Color(0xFF8C91A0), style = MaterialTheme.typography.bodySmall)
                }
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                ) {
                    Text(
                        text = "镜 ${activeShot.orderIndex + 1} · ${activeShot.title}" + if (hasVideo) " · 🎬" else "",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        onClick = {
                            if (!isPlaying) {
                                playIndex = shots.indexOfFirst { it.id == selectedShotId }.coerceAtLeast(0)
                                shotElapsedMs = 0L
                                audioTriggeredForShotId = null
                            }
                            isPlaying = !isPlaying
                        }
                    ) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (isPlaying) "暂停" else "预览")
                    }
                    IconButton(onClick = {
                        isPlaying = false; playIndex = 0; shotElapsedMs = 0L; selectedShotId = shots.first().id
                    }) { Icon(Icons.Filled.Replay, contentDescription = "重播") }
                    Button(
                        enabled = !isExporting,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        onClick = {
                            isPlaying = false; isExporting = true; exportProgress = 0f
                            scope.launch {
                                runCatching {
                                    Mp4Exporter.exportShotsToMp4(context, shots, "OpenAnimation") { exportProgress = it }
                                }.onSuccess { isExporting = false; onStatus(it) }
                                    .onFailure { isExporting = false; onStatus("导出失败：${it.message ?: "未知错误"}") }
                            }
                        }
                    ) { Text(if (isExporting) "${(exportProgress * 100).toInt()}%" else "导出MP4") }
                }
                Text("${formatMs(currentTimelineMs)}/${formatMs(totalDurationMs)}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }

    @Composable
    fun TimelineAndInspector(modifier: Modifier = Modifier) {
        Column(modifier.verticalScroll(rememberScrollState())) {
            Text("时间轴轨道", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(shots, key = { _, s -> s.id }) { idx, shot ->
                    val isSelected = shot.id == activeShot.id
                    val clipReady = !shot.videoClipPath.isNullOrBlank()
                    val widthDp = ((shot.durationMs / 1000f) * 18f).coerceIn(104f, 200f).dp
                    var thumb by remember(shot.firstFramePath) { mutableStateOf<Bitmap?>(null) }
                    LaunchedEffect(shot.firstFramePath) {
                        thumb = shot.firstFramePath?.let { decodeSampledBitmap(it, 240) }
                    }
                    Card(
                        modifier = Modifier
                            .width(widthDp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                isPlaying = false; selectedShotId = shot.id; playIndex = idx; shotElapsedMs = 0L
                            }
                    ) {
                        Column(Modifier.padding(6.dp)) {
                            if (thumb != null) {
                                Image(
                                    bitmap = thumb!!.asImageBitmap(),
                                    contentDescription = shot.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(Modifier.height(4.dp))
                            }
                            Text("${idx + 1}. ${shot.title}", maxLines = 1, style = MaterialTheme.typography.labelMedium)
                            Text(
                                "${"%.1f".format(shot.durationMs / 1000f)}s" +
                                    (if (clipReady) " · 🎬" else "") +
                                    (if (!shot.audioPath.isNullOrBlank()) " · ♫" else ""),
                                style = MaterialTheme.typography.labelSmall
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                IconButton(onClick = { onMoveShot(shot, -1) }, enabled = idx > 0, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Filled.ArrowBack, contentDescription = "前移", modifier = Modifier.size(14.dp))
                                }
                                IconButton(onClick = { onMoveShot(shot, 1) }, enabled = idx < shots.lastIndex, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Filled.ArrowForward, contentDescription = "后移", modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            HorizontalDivider()
            Spacer(Modifier.height(10.dp))

            var durationSec by remember(activeShot.id, activeShot.durationMs) { mutableFloatStateOf(activeShot.durationMs / 1000f) }
            var muteOriginal by remember(activeShot.id, activeShot.muteOriginalAudio) { mutableStateOf(activeShot.muteOriginalAudio) }
            var audioStartSec by remember(activeShot.id, activeShot.audioStartMs) { mutableFloatStateOf(activeShot.audioStartMs / 1000f) }

            Text("镜头设置 · ${activeShot.title}", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Movie, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (hasVideo) "换视频" else "导视频")
                }
                if (hasVideo) {
                    Button(onClick = { onExtractLastFrameToNext(activeShot) }, modifier = Modifier.weight(1f)) {
                        Text("截尾帧→下镜")
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("静音原片声音（只留音效）", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                Switch(checked = muteOriginal, onCheckedChange = {
                    muteOriginal = it
                    onSaveShot(activeShot.copy(muteOriginalAudio = it))
                })
            }

            ParamSlider("时长（默认 6.0 秒）", "${"%.1f".format(durationSec)}s", durationSec, 1f..15f) {
                durationSec = (it * 2f).roundToInt() / 2f
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Filled.Audiotrack, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (activeShot.audioPath.isNullOrBlank()) "导入音效" else "更换音效")
                }
                if (!activeShot.audioPath.isNullOrBlank()) {
                    Text("已绑定音效", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        onSaveShot(activeShot.copy(audioPath = null, audioStartMs = 0L))
                        onStatus("已移除音效")
                    }) { Icon(Icons.Filled.Delete, contentDescription = "清除音效") }
                }
            }
            if (!activeShot.audioPath.isNullOrBlank()) {
                ParamSlider("音效起始", "${"%.1f".format(audioStartSec)}s", audioStartSec, 0f..durationSec) {
                    audioStartSec = (it * 2f).roundToInt() / 2f
                }
            }

            Spacer(Modifier.height(6.dp))
            Button(
                onClick = {
                    onSaveShot(
                        activeShot.copy(
                            durationMs = (durationSec * 1000f).toLong().coerceAtLeast(500L),
                            muteOriginalAudio = muteOriginal,
                            audioStartMs = (audioStartSec * 1000f).toLong()
                        )
                    )
                    onStatus("已保存「${activeShot.title}」设置")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("保存镜头设置") }
        }
    }

    if (isLandscape) {
        Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PreviewAndControls(Modifier.weight(0.48f).fillMaxHeight())
            TimelineAndInspector(Modifier.weight(0.52f).fillMaxHeight())
        }
    } else {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            PreviewAndControls(Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            TimelineAndInspector(Modifier.fillMaxWidth().weight(1f))
        }
    }
}

@Composable
private fun ParamSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(valueText, style = MaterialTheme.typography.labelMedium)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range)
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    return "%02d:%02d".format(totalSec / 60L, totalSec % 60L)
}
