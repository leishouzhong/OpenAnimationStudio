package org.openanimationstudio.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: ProjectEntity)
    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProject(id: String): ProjectEntity?
    @Query("UPDATE projects SET scriptText = :text, updatedAt = :now WHERE id = :projectId")
    suspend fun updateScript(projectId: String, text: String, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM characters WHERE projectId = :projectId ORDER BY name")
    fun observeCharacters(projectId: String): Flow<List<CharacterEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCharacter(character: CharacterEntity)
    @Query("SELECT * FROM characters WHERE id = :id LIMIT 1")
    suspend fun getCharacter(id: String): CharacterEntity?
    @Query("SELECT * FROM character_card_versions WHERE characterId = :characterId ORDER BY versionNumber DESC")
    fun observeCardVersions(characterId: String): Flow<List<CharacterCardVersionEntity>>
    @Query("SELECT * FROM character_card_versions WHERE id = :versionId LIMIT 1")
    suspend fun getCardVersion(versionId: String): CharacterCardVersionEntity?
    @Query("SELECT versionNumber FROM character_card_versions WHERE characterId = :characterId")
    suspend fun getCardVersionNumbers(characterId: String): List<Int>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCardVersion(version: CharacterCardVersionEntity)
    @Query("SELECT MAX(versionNumber) FROM character_card_versions WHERE characterId = :characterId")
    suspend fun maxCardVersion(characterId: String): Int?
    @Query("UPDATE characters SET activeVersionId = :versionId WHERE id = :characterId")
    suspend fun setActiveCardVersion(characterId: String, versionId: String?)
    @Query("UPDATE characters SET locked = :locked WHERE id = :characterId")
    suspend fun setCharacterLocked(characterId: String, locked: Boolean)

    @Query("SELECT * FROM shots WHERE projectId = :projectId ORDER BY orderIndex")
    fun observeShots(projectId: String): Flow<List<ShotEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShot(shot: ShotEntity)
    @Query("DELETE FROM shots WHERE id = :shotId")
    suspend fun deleteShot(shotId: String)
    @Transaction
    suspend fun deleteShotAndNormalize(shotId: String, projectId: String) {
        deleteShot(shotId)
        getShotsForProject(projectId).forEachIndexed { index, shot -> updateShotOrder(shot.id, index) }
    }
    @Query("SELECT * FROM shots WHERE projectId = :projectId ORDER BY orderIndex")
    suspend fun getShotsForProject(projectId: String): List<ShotEntity>
    @Query("UPDATE shots SET orderIndex = :index WHERE id = :shotId")
    suspend fun updateShotOrder(shotId: String, index: Int)
    @Transaction
    suspend fun swapShotOrder(first: ShotEntity, second: ShotEntity) {
        updateShotOrder(first.id, -1)
        updateShotOrder(second.id, first.orderIndex)
        updateShotOrder(first.id, second.orderIndex)
    }
    @Query("SELECT * FROM shots WHERE id = :shotId LIMIT 1")
    suspend fun getShot(shotId: String): ShotEntity?

    @Query("DELETE FROM shot_character_references WHERE shotId = :shotId AND characterId = :characterId")
    suspend fun deleteShotCharacterReference(shotId: String, characterId: String)
    @Query("SELECT * FROM shot_character_references WHERE shotId = :shotId")
    suspend fun getShotCharacterReferences(shotId: String): List<ShotCharacterReferenceEntity>

    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY name")
    fun observeScenes(projectId: String): Flow<List<SceneEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertScene(scene: SceneEntity)
    @Query("SELECT * FROM props WHERE projectId = :projectId ORDER BY name")
    fun observeProps(projectId: String): Flow<List<PropEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProp(prop: PropEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShotCharacterReference(reference: ShotCharacterReferenceEntity)
    @Query("SELECT * FROM shot_character_references WHERE shotId = :shotId")
    fun observeShotCharacterReferences(shotId: String): Flow<List<ShotCharacterReferenceEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGenerationSnapshot(snapshot: GenerationSnapshotEntity)

    @Query("UPDATE characters SET name = :name WHERE id = :characterId")
    suspend fun renameCharacter(characterId: String, name: String)
    @Query("DELETE FROM character_card_versions WHERE characterId = :characterId")
    suspend fun deleteVersionsForCharacter(characterId: String)
    @Query("DELETE FROM shot_character_references WHERE characterId = :characterId")
    suspend fun deleteReferencesForCharacter(characterId: String)
    @Query("DELETE FROM characters WHERE id = :characterId")
    suspend fun deleteCharacter(characterId: String)
    @Transaction
    suspend fun deleteCharacterCascade(characterId: String) {
        deleteReferencesForCharacter(characterId)
        deleteVersionsForCharacter(characterId)
        deleteCharacter(characterId)
    }
    @Query("UPDATE scenes SET name = :name WHERE id = :sceneId")
    suspend fun renameScene(sceneId: String, name: String)
    @Query("DELETE FROM scenes WHERE id = :sceneId")
    suspend fun deleteScene(sceneId: String)
    @Query("UPDATE props SET name = :name WHERE id = :propId")
    suspend fun renameProp(propId: String, name: String)
    @Query("DELETE FROM props WHERE id = :propId")
    suspend fun deleteProp(propId: String)

}
