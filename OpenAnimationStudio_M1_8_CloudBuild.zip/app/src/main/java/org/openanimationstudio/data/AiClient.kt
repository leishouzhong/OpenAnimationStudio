package org.openanimationstudio.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    suspend fun generateScript(cfg: AiConfig, idea: String): String = withContext(Dispatchers.IO) {
        require(cfg.textApiKey.isNotBlank()) { "请先在「AI配置」中填写文本 API Key" }
        val styleHint = if (cfg.silentMode) {
            "要求：极简2D无声荒诞幽默风格，全程无对白，只用动作和画面反差搞笑，不加背景音乐。"
        } else {
            "要求：分镜清晰，画面描述具体。"
        }
        val prompt = """
            请根据以下创意写一个6镜头的动画短片分镜剧本。$styleHint
            必须严格按如下格式输出每个镜头，方便软件自动拆解：
            镜头 1｜镜头标题
            首帧：画面起点描述
            尾帧：画面终点描述

            创意：$idea
        """.trimIndent()

        if (cfg.textProviderType == "GEMINI") {
            val base = cfg.textBaseUrl.trimEnd('/')
            val url = "$base/models/${cfg.textModel.trim()}:generateContent?key=${cfg.textApiKey.trim()}"
            val body = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().apply { put("text", prompt) }))
                }))
            }
            val resp = requestJson("POST", url, body.toString(), emptyMap())
            val json = JSONObject(resp)
            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } else {
            val base = cfg.textBaseUrl.trimEnd('/')
            val url = "$base/chat/completions"
            val body = JSONObject().apply {
                put("model", cfg.textModel.trim())
                put("messages", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                }))
            }
            val headers = mapOf("Authorization" to "Bearer ${cfg.textApiKey.trim()}")
            val resp = requestJson("POST", url, body.toString(), headers)
            val json = JSONObject(resp)
            json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    suspend fun generateImageBytes(cfg: AiConfig, prompt: String): ByteArray = withContext(Dispatchers.IO) {
        val fullPrompt = "minimalist 2D flat illustration, clean black ink outlines, muted pale horror comedy style, $prompt"
        if (cfg.imageProviderType == "HORDE") {
            return@withContext generateViaHorde(cfg, fullPrompt)
        }
        require(cfg.imageApiKey.isNotBlank()) { "请先在「AI配置」中填写生图 API Key" }
        val base = cfg.imageBaseUrl.trimEnd('/')
        val url = "$base/images/generations"
        val body = JSONObject().apply {
            put("model", cfg.imageModel.trim())
            put("prompt", fullPrompt)
            put("size", "1024x1024")
            put("n", 1)
        }
        val headers = mapOf("Authorization" to "Bearer ${cfg.imageApiKey.trim()}")
        val resp = requestJson("POST", url, body.toString(), headers)
        val json = JSONObject(resp)
        val item = json.optJSONArray("images")?.optJSONObject(0)
            ?: json.optJSONArray("data")?.optJSONObject(0)
            ?: error("生图接口未返回图片数据")
        val b64 = item.optString("b64_json", "")
        if (b64.isNotBlank()) {
            Base64.decode(b64, Base64.DEFAULT)
        } else {
            val imgUrl = item.optString("url", "")
            require(imgUrl.isNotBlank()) { "生图接口未返回图片 URL 或 Base64" }
            downloadBytes(imgUrl)
        }
    }

    private suspend fun generateViaHorde(cfg: AiConfig, prompt: String): ByteArray {
        val apiKey = cfg.imageApiKey.trim().ifBlank { "0000000000" }
        val base = cfg.imageBaseUrl.trimEnd('/').ifBlank { "https://stablehorde.net/api/v2" }
        val headers = mapOf(
            "apikey" to apiKey,
            "Client-Agent" to "OpenAnimationStudio:0.8.4:android"
        )
        val body = JSONObject().apply {
            put("prompt", prompt)
            put("params", JSONObject().apply {
                put("width", 512)
                put("height", 512)
                put("steps", 20)
                put("n", 1)
            })
            put("nsfw", false)
            put("censor_nsfw", true)
        }
        val submitResp = requestJson("POST", "$base/generate/async", body.toString(), headers)
        val id = JSONObject(submitResp).optString("id", "")
        require(id.isNotBlank()) { "AI Horde 提交失败：$submitResp" }

        repeat(30) {
            delay(4000L)
            val checkResp = requestJson("GET", "$base/generate/check/$id", null, headers)
            val checkJson = JSONObject(checkResp)
            if (checkJson.optBoolean("faulted", false)) {
                error("AI Horde 队列出错，请重试")
            }
            if (checkJson.optBoolean("done", false)) {
                val statusResp = requestJson("GET", "$base/generate/status/$id", null, headers)
                val gens = JSONObject(statusResp).optJSONArray("generations")
                val first = gens?.optJSONObject(0) ?: error("AI Horde 未返回生成结果")
                val imgVal = first.optString("img", "")
                require(imgVal.isNotBlank()) { "AI Horde 返回空图片" }
                return if (imgVal.startsWith("http")) downloadBytes(imgVal) else Base64.decode(imgVal, Base64.DEFAULT)
            }
        }
        error("AI Horde 免费排队超时（当前人数较多），请稍后重试")
    }

    suspend fun generateVideoBytes(cfg: AiConfig, prompt: String, firstFramePath: String?): ByteArray = withContext(Dispatchers.IO) {
        require(cfg.videoApiKey.isNotBlank()) { "请先在「AI配置」中填写视频 API Key" }
        val base = cfg.videoBaseUrl.trimEnd('/')
        val silentSuffix = if (cfg.silentMode) ", silent animation, no background music, crisp sound effects only" else ""
        val body = JSONObject().apply {
            put("model", cfg.videoModel.trim())
            put("prompt", "$prompt$silentSuffix")
            if (!firstFramePath.isNullOrBlank() && File(firstFramePath).exists()) {
                val b64 = Base64.encodeToString(File(firstFramePath).readBytes(), Base64.NO_WRAP)
                put("image", "data:image/png;base64,$b64")
            }
        }
        val headers = mapOf("Authorization" to "Bearer ${cfg.videoApiKey.trim()}")
        val submitResp = requestJson("POST", "$base/video/submit", body.toString(), headers)
        val submitJson = JSONObject(submitResp)
        val requestId = submitJson.optString("requestId", submitJson.optString("id", ""))
        require(requestId.isNotBlank()) { "视频任务提交失败：$submitResp" }

        repeat(45) {
            delay(4000L)
            val statusBody = JSONObject().apply { put("requestId", requestId) }.toString()
            val statusResp = requestJson("POST", "$base/video/status", statusBody, headers)
            val statusJson = JSONObject(statusResp)
            val status = statusJson.optString("status", "")
            if (status.equals("Succeed", true) || status.equals("SUCCEEDED", true) || status.equals("completed", true)) {
                val results = statusJson.optJSONObject("results")
                val videoUrl = results?.optJSONArray("videos")?.optJSONObject(0)?.optString("url", "")
                    ?: statusJson.optString("video_url", "")
                require(videoUrl.isNotBlank()) { "任务完成但未返回视频地址" }
                return@withContext downloadBytes(videoUrl)
            }
            if (status.equals("Failed", true) || status.equals("FAILED", true)) {
                error("视频生成失败：${statusJson.optString("reason", statusResp)}")
            }
        }
        error("视频生成超时，请稍后重试")
    }

    private fun requestJson(method: String, urlStr: String, body: String?, headers: Map<String, String>): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 60_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null) doOutput = true
        }
        if (body != null) {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) error("HTTP $code: ${text.take(240)}")
        return text
    }

    private fun downloadBytes(urlStr: String): ByteArray {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
        }
        return conn.inputStream.use { it.readBytes() }
    }
}
