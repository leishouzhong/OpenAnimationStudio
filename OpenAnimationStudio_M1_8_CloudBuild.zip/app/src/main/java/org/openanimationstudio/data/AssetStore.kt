package org.openanimationstudio.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class ImportedAsset(val absolutePath: String, val sha256: String, val fileName: String)

class AssetStore(private val root: File) {
    fun importUri(resolver: ContentResolver, uri: Uri, projectId: String, category: String): ImportedAsset {
        val folder = File(File(root, projectId), category).apply { mkdirs() }
        val ext = if (category == "videos") "mp4" else "asset"
        val target = File(folder, "${UUID.randomUUID()}.$ext")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取所选文件" }.use { source ->
                target.outputStream().use { output -> source.copyTo(output) }
            }
        }
        return ImportedAsset(target.absolutePath, sha256(target), target.name)
    }

    fun saveBytes(bytes: ByteArray, projectId: String, category: String, ext: String): ImportedAsset {
        val folder = File(File(root, projectId), category).apply { mkdirs() }
        val target = File(folder, "${UUID.randomUUID()}.$ext")
        target.writeBytes(bytes)
        return ImportedAsset(target.absolutePath, sha256(target), target.name)
    }

    fun extractLastFrame(videoPath: String, projectId: String): ImportedAsset {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(videoPath)
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 1000L
            val targetUs = ((durMs - 100L).coerceAtLeast(0L)) * 1000L
            val bmp = retriever.getFrameAtTime(targetUs, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: retriever.getFrameAtTime(0L)
                ?: error("无法从视频中截取尾帧")
            val folder = File(File(root, projectId), "keyframes").apply { mkdirs() }
            val target = File(folder, "${UUID.randomUUID()}.png")
            target.outputStream().use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 95, out) }
            bmp.recycle()
            ImportedAsset(target.absolutePath, sha256(target), target.name)
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
