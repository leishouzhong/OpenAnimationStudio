package org.openanimationstudio.data

data class ParsedShot(
    val title: String,
    val description: String,
    val durationMs: Long = 6000L
)

object ScriptParser {
    private val headerRegex = Regex(
        """^(?:[#*\s]*)(?:(?:镜头|分镜)\s*\d+|第\s*\d+\s*镜|Shot\s*\d+|\d+[.)、])\s*[｜|：:\-—]?\s*(.+)$""",
        RegexOption.IGNORE_CASE
    )
    private val durationRegex = Regex("""(\d+(?:\.\d+)?)\s*(?:秒|s)\b""", RegexOption.IGNORE_CASE)

    fun parse(script: String): List<ParsedShot> {
        val lines = script.lines()
        val result = mutableListOf<ParsedShot>()
        var currentTitle: String? = null
        val currentBody = mutableListOf<String>()

        fun flush() {
            val rawTitle = currentTitle?.trim()?.trim('*', ' ', '：', ':') ?: return
            if (rawTitle.isBlank()) return
            val bodyText = currentBody.joinToString("\n").trim()
            val durMatch = durationRegex.find(rawTitle) ?: durationRegex.find(bodyText)
            val durationMs = durMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                ?.let { (it * 1000.0).toLong().coerceIn(1000L, 30000L) } ?: 6000L
            result += ParsedShot(title = rawTitle, description = bodyText, durationMs = durationMs)
        }

        for (rawLine in lines) {
            val trimmed = rawLine.trim()
            val match = headerRegex.matchEntire(trimmed)
            if (match != null) {
                flush()
                currentTitle = match.groupValues[1]
                currentBody.clear()
            } else if (currentTitle != null && trimmed.isNotEmpty() && !trimmed.startsWith("---")) {
                currentBody += trimmed.trimStart('*', '-', ' ')
            }
        }
        flush()

        if (result.isEmpty() && script.isNotBlank()) {
            val paragraphs = script.split(Regex("""\n\s*\n"""))
                .map { it.trim() }
                .filter { it.isNotBlank() }
            paragraphs.forEachIndexed { idx, para ->
                val firstLine = para.lines().firstOrNull()?.take(24) ?: "镜头 ${idx + 1}"
                result += ParsedShot(title = firstLine, description = para, durationMs = 6000L)
            }
        }
        return result
    }
}
