package org.openanimationstudio.data

import android.content.Context

data class AiConfig(
    val presetName: String = "免费文本 + AI Horde 免费生图",
    val textProviderType: String = "OPENAI", // "OPENAI" or "GEMINI"
    val textBaseUrl: String = "https://api.siliconflow.cn/v1",
    val textApiKey: String = "",
    val textModel: String = "THUDM/GLM-Z1-9B-0414",
    val imageProviderType: String = "OPENAI", // "HORDE" or "OPENAI"
    val imageBaseUrl: String = "https://api.siliconflow.cn/v1",
    val imageApiKey: String = "",
    val imageModel: String = "Kwai-Kolors/Kolors",
    val videoBaseUrl: String = "https://api.siliconflow.cn/v1",
    val videoApiKey: String = "",
    val videoModel: String = "Wan-AI/Wan2.1-I2V-14B-720P",
    val silentMode: Boolean = true
)

object AiSettingsStore {
    private const val PREF = "oas_ai_settings"

    fun load(context: Context): AiConfig {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return AiConfig(
            presetName = sp.getString("presetName", "免费文本 + AI Horde 免费生图") ?: "",
            textProviderType = "OPENAI",
            textBaseUrl = sp.getString("textBaseUrl", "https://api.siliconflow.cn/v1") ?: "https://api.siliconflow.cn/v1",
            textApiKey = sp.getString("textApiKey", "") ?: "",
            textModel = sp.getString("textModel", "THUDM/GLM-Z1-9B-0414") ?: "THUDM/GLM-Z1-9B-0414",
            imageProviderType = "OPENAI",
            imageBaseUrl = sp.getString("imageBaseUrl", "https://api.siliconflow.cn/v1") ?: "https://api.siliconflow.cn/v1",
            imageApiKey = sp.getString("imageApiKey", "") ?: "",
            imageModel = sp.getString("imageModel", "Kwai-Kolors/Kolors") ?: "Kwai-Kolors/Kolors",
            videoBaseUrl = sp.getString("videoBaseUrl", "https://api.siliconflow.cn/v1") ?: "",
            videoApiKey = sp.getString("videoApiKey", "") ?: "",
            videoModel = sp.getString("videoModel", "Wan-AI/Wan2.1-I2V-14B-720P") ?: "",
            silentMode = sp.getBoolean("silentMode", true)
        )
    }

    fun save(context: Context, cfg: AiConfig) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("presetName", cfg.presetName)
            .putString("textProviderType", cfg.textProviderType)
            .putString("textBaseUrl", cfg.textBaseUrl)
            .putString("textApiKey", cfg.textApiKey)
            .putString("textModel", cfg.textModel)
            .putString("imageProviderType", cfg.imageProviderType)
            .putString("imageBaseUrl", cfg.imageBaseUrl)
            .putString("imageApiKey", cfg.imageApiKey)
            .putString("imageModel", cfg.imageModel)
            .putString("videoBaseUrl", cfg.videoBaseUrl)
            .putString("videoApiKey", cfg.videoApiKey)
            .putString("videoModel", cfg.videoModel)
            .putBoolean("silentMode", cfg.silentMode)
            .apply()
    }
}
