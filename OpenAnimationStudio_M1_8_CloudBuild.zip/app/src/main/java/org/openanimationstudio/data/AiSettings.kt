package org.openanimationstudio.data

import android.content.Context

data class AiConfig(
    val presetName: String = "Gemini 免费文本 + 通用聚合",
    val textProviderType: String = "GEMINI", // "GEMINI" or "OPENAI"
    val textBaseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
    val textApiKey: String = "",
    val textModel: String = "gemini-2.5-flash",
    val imageBaseUrl: String = "https://api.siliconflow.cn/v1",
    val imageApiKey: String = "",
    val imageModel: String = "Kwai-Kolors/Kolors",
    val videoBaseUrl: String = "https://api.siliconflow.cn/v1",
    val videoApiKey: String = "",
    val videoModel: String = "Wan-AI/Wan2.1-I2V-14B-720P",
    val silentMode: Boolean = true
)

object AiSettingsStore {
    private const val PREF = "oas_ai_settings"

    fun load(context: Context): AiConfig {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return AiConfig(
            presetName = sp.getString("presetName", "Gemini 免费文本 + 通用聚合") ?: "Gemini 免费文本 + 通用聚合",
            textProviderType = sp.getString("textProviderType", "GEMINI") ?: "GEMINI",
            textBaseUrl = sp.getString("textBaseUrl", "https://generativelanguage.googleapis.com/v1beta") ?: "",
            textApiKey = sp.getString("textApiKey", "") ?: "",
            textModel = sp.getString("textModel", "gemini-2.5-flash") ?: "gemini-2.5-flash",
            imageBaseUrl = sp.getString("imageBaseUrl", "https://api.siliconflow.cn/v1") ?: "",
            imageApiKey = sp.getString("imageApiKey", "") ?: "",
            imageModel = sp.getString("imageModel", "Kwai-Kolors/Kolors") ?: "",
            videoBaseUrl = sp.getString("videoBaseUrl", "https://api.siliconflow.cn/v1") ?: "",
            videoApiKey = sp.getString("videoApiKey", "") ?: "",
            videoModel = sp.getString("videoModel", "Wan-AI/Wan2.1-I2V-14B-720P") ?: "",
            silentMode = sp.getBoolean("silentMode", true)
        )
    }

    fun save(context: Context, cfg: AiConfig) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("presetName", cfg.presetName)
            .putString("textProviderType", cfg.textProviderType)
            .putString("textBaseUrl", cfg.textBaseUrl)
            .putString("textApiKey", cfg.textApiKey)
            .putString("textModel", cfg.textModel)
            .putString("imageBaseUrl", cfg.imageBaseUrl)
            .putString("imageApiKey", cfg.imageApiKey)
            .putString("imageModel", cfg.imageModel)
            .putString("videoBaseUrl", cfg.videoBaseUrl)
            .putString("videoApiKey", cfg.videoApiKey)
            .putString("videoModel", cfg.videoModel)
            .putBoolean("silentMode", cfg.silentMode)
            .apply()
    }
}
