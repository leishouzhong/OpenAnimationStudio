package org.openanimationstudio.data

import android.content.Context

data class AiConfig(
    val presetName: String = "免费文本 + AI Horde 免费生图",
    val textProviderType: String = "OPENAI", // "OPENAI" or "GEMINI"
    val textBaseUrl: String = "https://openrouter.ai/api/v1",
    val textApiKey: String = "",
    val textModel: String = "deepseek/deepseek-r1:free",
    val imageProviderType: String = "HORDE", // "HORDE" or "OPENAI"
    val imageBaseUrl: String = "https://stablehorde.net/api/v2",
    val imageApiKey: String = "0000000000",
    val imageModel: String = "AlbedoBase XL (SDXL)",
    val videoBaseUrl: String = "https://api.siliconflow.cn/v1",
    val videoApiKey: String = "",
    val videoModel: String = "Wan-AI/Wan2.1-I2V-14B-720P",
    val silentMode: Boolean = true
)

object AiSettingsStore {
    private const val PREF = "oas_ai_settings"

    fun load(context: Context): AiConfig {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return AiConfig(
            presetName = sp.getString("presetName", "免费文本 + AI Horde 免费生图") ?: "",
            textProviderType = sp.getString("textProviderType", "OPENAI") ?: "OPENAI",
            textBaseUrl = sp.getString("textBaseUrl", "https://openrouter.ai/api/v1") ?: "",
            textApiKey = sp.getString("textApiKey", "") ?: "",
            textModel = sp.getString("textModel", "deepseek/deepseek-r1:free") ?: "",
            imageProviderType = sp.getString("imageProviderType", "HORDE") ?: "HORDE",
            imageBaseUrl = sp.getString("imageBaseUrl", "https://stablehorde.net/api/v2") ?: "https://stablehorde.net/api/v2",
            imageApiKey = sp.getString("imageApiKey", "0000000000") ?: "0000000000",
            imageModel = sp.getString("imageModel", "AlbedoBase XL (SDXL)") ?: "",
            videoBaseUrl = sp.getString("videoBaseUrl", "https://api.siliconflow.cn/v1") ?: "",
            videoApiKey = sp.getString("videoApiKey", "") ?: "",
            videoModel = sp.getString("videoModel", "Wan-AI/Wan2.1-I2V-14B-720P") ?: "",
            silentMode = sp.getBoolean("silentMode", true)
        )
    }

    fun save(context: Context, cfg: AiConfig) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("presetName", cfg.presetName)
            .putString("textProviderType", cfg.textProviderType)
            .putString("textBaseUrl", cfg.textBaseUrl)
            .putString("textApiKey", cfg.textApiKey)
            .putString("textModel", cfg.textModel)
            .putString("imageProviderType", cfg.imageProviderType)
            .putString("imageBaseUrl", cfg.imageBaseUrl)
            .putString("imageApiKey", cfg.imageApiKey)
            .putString("imageModel", cfg.imageModel)
            .putString("videoBaseUrl", cfg.videoBaseUrl)
            .putString("videoApiKey", cfg.videoApiKey)
            .putString("videoModel", cfg.videoModel)
            .putBoolean("silentMode", cfg.silentMode)
            .apply()
    }
}
