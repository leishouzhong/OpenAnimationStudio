package org.openanimationstudio

import android.app.Activity
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.openanimationstudio.data.*
import org.openanimationstudio.ui.LocalAssetPreview
import org.openanimationstudio.ui.TimelineTabContent
import java.io.File

private val StudioDarkColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF0E0D16),
    primaryContainer = Color(0xFF332D66),
    secondary = Color(0xFF4DD0E1),
    background = Color(0xFF101218),
    surface = Color(0xFF181B23),
    surfaceVariant = Color(0xFF232733),
    onBackground = Color(0xFFECEEF4),
    onSurface = Color(0xFFECEEF4)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = WorkspaceRepository(AppDatabase.get(this).dao())
        setContent {
            MaterialTheme(colorScheme = StudioDarkColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    StudioApp(repo)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudioApp(repo: WorkspaceRepository) {
    val context = LocalContext.current
    val activity = context as? Activity
    var isLandscape by remember { mutableStateOf(false) }
    val vm: StudioViewModel = viewModel(factory = StudioViewModel.Factory(repo))
    val projects by vm.projects.collectAsStateWithLifecycle(initialValue = emptyList())
    var activeProject by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    fun toggleOrientation() {
        isLandscape = !isLandscape
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    if (activeProject == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Open Animation Studio") },
                    actions = {
                        IconButton(onClick = { toggleOrientation() }) {
                            Icon(Icons.Filled.ScreenRotation, contentDescription = "切换横竖屏")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null) }
            }
        ) { padding ->
            LazyColumn(Modifier.padding(padding).padding(16.dp)) {
                item { Text("本地动画项目", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(12.dp)) }
                items(projects) { project ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { activeProject = project.id }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(project.name, style = MaterialTheme.typography.titleMedium)
                            Text("点击进入工作区", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (projects.isEmpty()) item { Text("还没有项目。点击右下角 + 创建你的第一个动画项目。") }
            }
        }
    } else {
        WorkspaceScreen(
            projectId = activeProject!!,
            repo = repo,
            onToggleOrientation = { toggleOrientation() },
            onBack = { activeProject = null }
        )
    }
    if (showCreate) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建项目") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("项目名称") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.create(name); showCreate = false }) { Text("创建") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkspaceScreen(
    projectId: String,
    repo: WorkspaceRepository,
    onToggleOrientation: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val vm: WorkspaceViewModel = viewModel(key = projectId, factory = WorkspaceViewModel.Factory(repo, projectId))
    val shots by vm.shots.collectAsStateWithLifecycle(initialValue = emptyList())
    val characters by vm.characters.collectAsStateWithLifecycle(initialValue = emptyList())
    val scenes by vm.scenes.collectAsStateWithLifecycle(initialValue = emptyList())
    val props by vm.props.collectAsStateWithLifecycle(initialValue = emptyList())

    var tab by remember { mutableIntStateOf(0) }
    var newShotTitle by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("") }
    var aiIdea by remember { mutableStateOf("") }
    var isAiBusy by remember { mutableStateOf(false) }
    var newCharacterName by remember { mutableStateOf("") }
    var pendingCharacterImport by remember { mutableStateOf(false) }
    var pendingVersionCharacter by remember { mutableStateOf<String?>(null) }
    var pendingKeyframeShot by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var pendingVideoShotId by remember { mutableStateOf<String?>(null) }
    var sceneName by remember { mutableStateOf("") }
    var propName by remember { mutableStateOf("") }
    var pendingReferenceImport by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var editShotTarget by remember { mutableStateOf<ShotEntity?>(null) }
    var aiConfig by remember { mutableStateOf(AiSettingsStore.load(context)) }
    var status by remember { mutableStateOf("") }
    val assetStore = remember(context, projectId) {
        AssetStore(File(context.filesDir, "projects"))
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            when {
                pendingCharacterImport -> {
                    val name = newCharacterName.trim().ifBlank { "角色 ${characters.size + 1}" }
                    vm.importCharacter(uri, context.contentResolver, assetStore, name) { result ->
                        status = result
                        newCharacterName = ""
                        pendingCharacterImport = false
                    }
                }
                pendingVersionCharacter != null -> {
                    val characterId = pendingVersionCharacter!!
                    vm.importVersion(uri, context.contentResolver, assetStore, characterId) { result ->
                        status = result
                        pendingVersionCharacter = null
                    }
                }
                pendingKeyframeShot != null -> {
                    val (shotId, isFirst) = pendingKeyframeShot!!
                    vm.importKeyframe(uri, context.contentResolver, assetStore, shotId, isFirst) { result ->
                        status = result
                        pendingKeyframeShot = null
                    }
                }
                pendingReferenceImport == "scene" -> {
                    val name = sceneName.trim().ifBlank { "场景 ${scenes.size + 1}" }
                    vm.addSceneWithImage(name, uri, context.contentResolver, assetStore) { result ->
                        status = result
                        sceneName = ""
                        pendingReferenceImport = null
                    }
                }
                pendingReferenceImport == "prop" -> {
                    val name = propName.trim().ifBlank { "道具 ${props.size + 1}" }
                    vm.addPropWithImage(name, uri, context.contentResolver, assetStore) { result ->
                        status = result
                        propName = ""
                        pendingReferenceImport = null
                    }
                }
            }
        } else {
            pendingCharacterImport = false
            pendingVersionCharacter = null
            pendingKeyframeShot = null
            pendingReferenceImport = null
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val shotId = pendingVideoShotId
        pendingVideoShotId = null
        if (uri != null && shotId != null) {
            vm.importVideoClip(uri, context.contentResolver, assetStore, shotId) { status = it }
        }
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    LaunchedEffect(projectId) { script = vm.loadScript() }

    @Composable
    fun WorkspaceBody(modifier: Modifier = Modifier) {
        Column(modifier) {
            if (status.isNotBlank()) {
                Text(status, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
            }
            when (tab) {
                0 -> Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = aiIdea, onValueChange = { aiIdea = it },
                            modifier = Modifier.weight(1f), label = { Text("输入一句话脑洞（AI写剧本）") }, singleLine = true
                        )
                        Button(
                            enabled = !isAiBusy && aiIdea.isNotBlank(),
                            onClick = {
                                isAiBusy = true
                                status = "正在调用 AI 生成剧本…"
                                vm.aiGenerateScript(aiConfig, aiIdea) { ok, textOrErr ->
                                    isAiBusy = false
                                    if (ok) {
                                        script = textOrErr
                                        status = "AI 剧本已生成！点击下方「保存并一键拆解」即可建好分镜"
                                    } else {
                                        status = "生成失败：$textOrErr"
                                    }
                                }
                            }
                        ) { Text(if (isAiBusy) "生成中" else "AI生成") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = script, onValueChange = { script = it },
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        placeholder = { Text("在这里编写或粘贴剧本（支持按「镜头 1｜标题」格式自动拆解）……") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { vm.saveScript(script); status = "剧本已保存" },
                            modifier = Modifier.weight(1f)
                        ) { Text("仅保存剧本") }
                        Button(
                            onClick = {
                                vm.saveAndParseScript(script) { count ->
                                    if (count > 0) {
                                        status = "已保存并拆解出 $count 个分镜"
                                        tab = 1
                                    } else {
                                        status = "剧本已保存，但未识别到可拆解的段落"
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("保存并一键拆解") }
                    }
                }
                1 -> Column(Modifier.padding(16.dp)) {
                    Text("分镜列表 · ${shots.size} 镜", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newShotTitle, onValueChange = { newShotTitle = it },
                            modifier = Modifier.weight(1f), label = { Text("镜头标题（留空自动编号）") }, singleLine = true
                        )
                        Button(onClick = {
                            val title = newShotTitle.trim().ifBlank { "镜头 ${shots.size + 1}" }
                            vm.addShot(title, shots.size)
                            newShotTitle = ""
                            status = "已添加：$title"
                        }) { Text("添加") }
                    }
                    LazyColumn {
                        items(shots, key = { it.id }) { shot ->
                            val hasClip = !shot.videoClipPath.isNullOrBlank() && File(shot.videoClipPath).exists()
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(
                                        "镜头 ${shot.orderIndex + 1} · ${shot.title}（${"%.1f".format(shot.durationMs / 1000f)}s）" +
                                            if (hasClip) " · 🎬已出片" else "",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(shot.description.ifBlank { "尚未填写镜头内容" }, style = MaterialTheme.typography.bodySmall)
                                    Text("首帧：${shot.firstFramePath?.substringAfterLast('/') ?: "未导入"}", style = MaterialTheme.typography.labelSmall)
                                    if (shot.firstFramePath != null) LocalAssetPreview(shot.firstFramePath, "首帧预览")
                                    Text("尾帧：${shot.lastFramePath?.substringAfterLast('/') ?: "未导入"}", style = MaterialTheme.typography.labelSmall)
                                    if (shot.lastFramePath != null) LocalAssetPreview(shot.lastFramePath, "尾帧预览")

                                    val boundRefs by vm.observeShotReferences(shot.id).collectAsStateWithLifecycle(initialValue = emptyList())
                                    if (boundRefs.isNotEmpty()) {
                                        Text("已绑定角色：", style = MaterialTheme.typography.labelMedium)
                                        boundRefs.forEach { ref ->
                                            val charName = characters.firstOrNull { it.id == ref.characterId }?.name ?: "未知角色"
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("• $charName", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                                TextButton(onClick = {
                                                    vm.unbindCharacter(shot.id, ref.characterId)
                                                    status = "已移除绑定：$charName"
                                                }) { Text("移除") }
                                            }
                                        }
                                    }
                                    var showBind by remember(shot.id) { mutableStateOf(false) }
                                    TextButton(onClick = { showBind = !showBind }) { Text(if (showBind) "收起角色选择" else "绑定角色卡（可多选）") }
                                    if (showBind) {
                                        if (characters.isEmpty()) Text("请先到「角色」页导入角色卡", style = MaterialTheme.typography.bodySmall)
                                        characters.forEach { character ->
                                            val versions by vm.observeVersions(character.id).collectAsStateWithLifecycle(initialValue = emptyList())
                                            val isBound = boundRefs.any { it.characterId == character.id }
                                            Text("${character.name}${if (isBound) "（已绑定）" else ""}", style = MaterialTheme.typography.labelLarge)
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                versions.forEach { version ->
                                                    TextButton(onClick = {
                                                        vm.bindCharacterVersion(shot.id, character.id, version.id)
                                                        status = "已绑定 ${character.name} 版本 ${version.versionNumber}"
                                                    }) { Text("版本 ${version.versionNumber}") }
                                                }
                                            }
                                        }
                                    }

                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        OutlinedButton(
                                            enabled = !isAiBusy,
                                            onClick = {
                                                isAiBusy = true
                                                status = "正在免费排队生成「${shot.title}」首帧（约30-50秒）…"
                                                val boundNames = boundRefs.mapNotNull { ref -> characters.firstOrNull { it.id == ref.characterId }?.name }
                                                vm.aiGenerateFirstFrame(aiConfig, shot, boundNames, assetStore) { msg ->
                                                    isAiBusy = false; status = msg
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("AI生首帧") }
                                        Button(
                                            enabled = !isAiBusy,
                                            onClick = {
                                                isAiBusy = true
                                                status = "正在为「${shot.title}」AI生成视频（约需1-2分钟）…"
                                                vm.aiGenerateVideo(aiConfig, shot, assetStore) { msg ->
                                                    isAiBusy = false; status = msg
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("AI生视频") }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        TextButton(onClick = { pendingKeyframeShot = shot.id to true; imagePicker.launch(arrayOf("image/*")) }) { Text("导首帧") }
                                        TextButton(onClick = { pendingVideoShotId = shot.id; videoPicker.launch(arrayOf("video/*")) }) { Text("导视频") }
                                        if (hasClip) {
                                            TextButton(onClick = {
                                                vm.extractLastFrameToNext(shot, shots, assetStore) { status = it }
                                            }) { Text("截尾帧→下镜") }
                                        }
                                        TextButton(onClick = { editShotTarget = shot }) { Text("编辑") }
                                        TextButton(onClick = { vm.delete(shot.id); status = "镜头已删除" }) { Text("删除") }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> TimelineTabContent(
                    shots = shots,
                    assetStore = assetStore,
                    onSaveShot = { vm.saveShot(it) },
                    onMoveShot = { shot, delta -> vm.move(shot, delta, shots) },
                    onExtractLastFrameToNext = { shot -> vm.extractLastFrameToNext(shot, shots, assetStore) { status = it } },
                    onStatus = { status = it }
                )
                3 -> {
                    @Composable
                    fun CharInput(m: Modifier) = Column(m) {
                        Text("角色卡资产", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = newCharacterName, onValueChange = { newCharacterName = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("角色名称（留空自动编号）") }, singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = {
                            pendingCharacterImport = true
                            imagePicker.launch(arrayOf("image/*"))
                        }, modifier = Modifier.fillMaxWidth()) { Text("导入新角色卡") }
                    }
                    @Composable
                    fun CharList(m: Modifier) = LazyColumn(m) {
                        items(characters, key = { it.id }) { character ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text(character.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { renameTarget = Triple("character", character.id, character.name) }) { Text("改名") }
                                        TextButton(onClick = { vm.deleteCharacter(character.id); status = "已删除角色：${character.name}" }) {
                                            Text("删除", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                    val versions by vm.observeVersions(character.id).collectAsStateWithLifecycle(initialValue = emptyList())
                                    versions.firstOrNull { it.id == character.activeVersionId }?.let { active ->
                                        LocalAssetPreview(active.primaryAssetPath, "当前角色卡")
                                    }
                                    versions.forEach { version ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("版本 ${version.versionNumber}${if (character.activeVersionId == version.id) " · 当前" else ""}",
                                                modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                            if (character.activeVersionId != version.id) {
                                                TextButton(onClick = { vm.restoreVersion(character.id, version.id); status = "已切换角色卡版本" }) { Text("设为当前") }
                                            }
                                        }
                                    }
                                    Row {
                                        TextButton(onClick = {
                                            pendingVersionCharacter = character.id
                                            imagePicker.launch(arrayOf("image/*"))
                                        }) { Text("导入新版本") }
                                        TextButton(onClick = { vm.setLocked(character.id, !character.locked) }) {
                                            Text(if (character.locked) "解除锁定" else "锁定角色卡")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (isLandscape) {
                        Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CharInput(Modifier.weight(0.36f))
                            CharList(Modifier.weight(0.64f).fillMaxHeight())
                        }
                    } else {
                        Column(Modifier.padding(16.dp)) {
                            CharInput(Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            CharList(Modifier.fillMaxSize())
                        }
                    }
                }
                4 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("场景与道具素材", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(sceneName, { sceneName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("场景名称（留空自动编号）") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val name = sceneName.trim().ifBlank { "场景 ${scenes.size + 1}" }
                            vm.addScene(name); sceneName = ""; status = "场景已添加：$name"
                        }, modifier = Modifier.weight(1f)) { Text("仅添加名称") }
                        Button(onClick = {
                            pendingReferenceImport = "scene"
                            imagePicker.launch(arrayOf("image/*"))
                        }, modifier = Modifier.weight(1f)) { Text("选图并创建") }
                    }
                    scenes.forEach { scene ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("场景 · ${scene.name}", modifier = Modifier.weight(1f))
                                    TextButton(onClick = { renameTarget = Triple("scene", scene.id, scene.name) }) { Text("改名") }
                                    TextButton(onClick = { vm.deleteScene(scene.id); status = "已删除场景：${scene.name}" }) {
                                        Text("删除", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                                scene.referenceImagePath?.let { LocalAssetPreview(it, "场景参考图") }
                            }
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    OutlinedTextField(propName, { propName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("道具名称（留空自动编号）") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val name = propName.trim().ifBlank { "道具 ${props.size + 1}" }
                            vm.addProp(name); propName = ""; status = "道具已添加：$name"
                        }, modifier = Modifier.weight(1f)) { Text("仅添加名称") }
                        Button(onClick = {
                            pendingReferenceImport = "prop"
                            imagePicker.launch(arrayOf("image/*"))
                        }, modifier = Modifier.weight(1f)) { Text("选图并创建") }
                    }
                    props.forEach { prop ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("道具 · ${prop.name}", modifier = Modifier.weight(1f))
                                    TextButton(onClick = { renameTarget = Triple("prop", prop.id, prop.name) }) { Text("改名") }
                                    TextButton(onClick = { vm.deleteProp(prop.id); status = "已删除道具：${prop.name}" }) {
                                        Text("删除", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                                prop.referenceImagePath?.let { LocalAssetPreview(it, "道具参考图") }
                            }
                        }
                    }
                }
                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("AI 接口配置（自填免费或大额 Key）", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            aiConfig = aiConfig.copy(
                                presetName = "Gemini 免费文本",
                                textProviderType = "GEMINI",
                                textBaseUrl = "https://generativelanguage.googleapis.com/v1beta",
                                textModel = "gemini-2.5-flash"
                            )
                            status = "已套用 Gemini 免费文本预设"
                        }, modifier = Modifier.weight(1f)) { Text("Gemini 文本预设") }
                        OutlinedButton(onClick = {
                            val key = aiConfig.imageApiKey.ifBlank { aiConfig.textApiKey }
                            aiConfig = aiConfig.copy(
                                presetName = "硅基流动单 Key 全包",
                                textProviderType = "OPENAI",
                                textBaseUrl = "https://api.siliconflow.cn/v1",
                                textModel = "Qwen/Qwen2.5-7B-Instruct",
                                imageBaseUrl = "https://api.siliconflow.cn/v1",
                                imageModel = "Kwai-Kolors/Kolors",
                                videoBaseUrl = "https://api.siliconflow.cn/v1",
                                videoModel = "Wan-AI/Wan2.1-I2V-14B-720P",
                                textApiKey = key,
                                imageApiKey = key,
                                videoApiKey = key
                            )
                            status = "已套用硅基流动单 Key 预设"
                        }, modifier = Modifier.weight(1f)) { Text("硅基流动预设") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("无声动画模式（自动禁止BGM）", style = MaterialTheme.typography.bodyMedium)
                            Text("生成提示词时自动要求无背景音乐、只留干净动作", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = aiConfig.silentMode, onCheckedChange = { aiConfig = aiConfig.copy(silentMode = it) })
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("1. 剧本大模型（文本）", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = aiConfig.textProviderType == "OPENAI",
                            onClick = { aiConfig = aiConfig.copy(textProviderType = "OPENAI") },
                            label = { Text("通用 OpenAI 格式（不限平台）") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = aiConfig.textProviderType == "GEMINI",
                            onClick = { aiConfig = aiConfig.copy(textProviderType = "GEMINI") },
                            label = { Text("Gemini 原生格式") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(aiConfig.textBaseUrl, { aiConfig = aiConfig.copy(textBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("文本 API 地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.textModel, { aiConfig = aiConfig.copy(textModel = it) }, Modifier.fillMaxWidth(), label = { Text("文本模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.textApiKey, { aiConfig = aiConfig.copy(textApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("文本 API Key") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Text("2. 首帧生图模型", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = aiConfig.imageProviderType == "HORDE",
                            onClick = {
                                aiConfig = aiConfig.copy(
                                    imageProviderType = "HORDE",
                                    imageBaseUrl = "https://stablehorde.net/api/v2",
                                    imageApiKey = aiConfig.imageApiKey.ifBlank { "0000000000" },
                                    imageModel = "AlbedoBase XL (SDXL)"
                                )
                            },
                            label = { Text("AI Horde 免费生图（0元免注册）") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = aiConfig.imageProviderType == "OPENAI",
                            onClick = { aiConfig = aiConfig.copy(imageProviderType = "OPENAI") },
                            label = { Text("OpenAI 兼容生图") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(aiConfig.imageBaseUrl, { aiConfig = aiConfig.copy(imageBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("生图 API 地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.imageModel, { aiConfig = aiConfig.copy(imageModel = it) }, Modifier.fillMaxWidth(), label = { Text("生图模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.imageApiKey, { aiConfig = aiConfig.copy(imageApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("生图 API Key") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Text("3. 图生视频模型", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(aiConfig.videoBaseUrl, { aiConfig = aiConfig.copy(videoBaseUrl = it) }, Modifier.fillMaxWidth(), label = { Text("视频 API 地址") }, singleLine = true)
                    OutlinedTextField(aiConfig.videoModel, { aiConfig = aiConfig.copy(videoModel = it) }, Modifier.fillMaxWidth(), label = { Text("视频模型名") }, singleLine = true)
                    OutlinedTextField(aiConfig.videoApiKey, { aiConfig = aiConfig.copy(videoApiKey = it) }, Modifier.fillMaxWidth(), label = { Text("视频 API Key") }, singleLine = true)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            enabled = !isAiBusy,
                            onClick = {
                                AiSettingsStore.save(context, aiConfig)
                                isAiBusy = true
                                status = "正在测试文本接口连通性…"
                                vm.aiGenerateScript(aiConfig, "小雷在电梯里遇到不按楼层的鬼（仅测试输出1个镜头）") { ok, res ->
                                    isAiBusy = false
                                    status = if (ok) "接口测试成功！返回内容：" + res.take(60) else "接口测试失败：$res"
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(if (isAiBusy) "测试中…" else "保存并测试") }
                        Button(onClick = {
                            AiSettingsStore.save(context, aiConfig)
                            status = "AI 配置已保存到本地"
                        }, modifier = Modifier.weight(1f)) { Text("仅保存配置") }
                    }
                }
            }
        }
    }

    if (isLandscape) {
        Row(Modifier.fillMaxSize()) {
            NavigationRail(
                modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()),
                header = {
                    Row {
                        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "返回") }
                    }
                }
            ) {
                NavigationRailItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Filled.Description, null) }, label = { Text("剧本") })
                NavigationRailItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Filled.Movie, null) }, label = { Text("分镜") })
                NavigationRailItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Filled.Timeline, null) }, label = { Text("时间轴") })
                NavigationRailItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Filled.Person, null) }, label = { Text("角色") })
                NavigationRailItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Filled.Landscape, null) }, label = { Text("场景") })
                NavigationRailItem(selected = tab == 5, onClick = { tab = 5 }, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("AI") })
                IconButton(onClick = onToggleOrientation) {
                    Icon(Icons.Filled.ScreenRotation, contentDescription = "切回竖屏")
                }
            }
            WorkspaceBody(Modifier.weight(1f).fillMaxHeight())
        }
    } else {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text("项目工作区") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = onToggleOrientation) {
                        Icon(Icons.Filled.ScreenRotation, contentDescription = "切换横竖屏")
                    }
                }
            )
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("剧本") })
                    Tab(tab == 1, { tab = 1 }, text = { Text("分镜") })
                    Tab(tab == 2, { tab = 2 }, text = { Text("时间轴") })
                    Tab(tab == 3, { tab = 3 }, text = { Text("角色") })
                    Tab(tab == 4, { tab = 4 }, text = { Text("场景道具") })
                    Tab(tab == 5, { tab = 5 }, text = { Text("AI配置") })
                }
                WorkspaceBody(Modifier.fillMaxSize())
            }
        }
    }

    editShotTarget?.let { target ->
        var titleEdit by remember(target.id) { mutableStateOf(target.title) }
        var descEdit by remember(target.id) { mutableStateOf(target.description) }
        AlertDialog(
            onDismissRequest = { editShotTarget = null },
            title = { Text("编辑镜头内容") },
            text = {
                Column {
                    OutlinedTextField(titleEdit, { titleEdit = it }, label = { Text("镜头标题") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(descEdit, { descEdit = it }, label = { Text("画面与首尾帧描述") }, minLines = 3)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveShot(target.copy(title = titleEdit.trim().ifBlank { target.title }, description = descEdit.trim()))
                    status = "已更新镜头「${titleEdit.trim()}」"
                    editShotTarget = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editShotTarget = null }) { Text("取消") } }
        )
    }

    renameTarget?.let { (type, id, oldName) ->
        var newName by remember(id) { mutableStateOf(oldName) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("修改名称") },
            text = { OutlinedTextField(newName, { newName = it }, label = { Text("新名称") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = newName.trim()
                    if (clean.isNotEmpty()) {
                        when (type) {
                            "character" -> vm.renameCharacter(id, clean)
                            "scene" -> vm.renameScene(id, clean)
                            "prop" -> vm.renameProp(id, clean)
                        }
                        status = "已改名为：$clean"
                    }
                    renameTarget = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("取消") } }
        )
    }
}

class StudioViewModel(private val repo: WorkspaceRepository) : ViewModel() {
    val projects = repo.projects()
    fun create(name: String) = viewModelScope.launch { repo.createProject(name) }
    class Factory(private val repo: WorkspaceRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = StudioViewModel(repo) as T
    }
}

class WorkspaceViewModel(private val repo: WorkspaceRepository, private val projectId: String) : ViewModel() {
    val shots = repo.shots(projectId)
    val characters = repo.characters(projectId)
    val scenes = repo.scenes(projectId)
    val props = repo.props(projectId)
    fun observeVersions(characterId: String) = repo.versions(characterId)
    fun observeShotReferences(shotId: String) = repo.observeShotReferences(shotId)
    fun unbindCharacter(shotId: String, characterId: String) = viewModelScope.launch { repo.unbindCharacter(shotId, characterId) }
    fun restoreVersion(characterId: String, versionId: String) = viewModelScope.launch { repo.restoreVersion(characterId, versionId) }
    fun renameCharacter(characterId: String, name: String) = viewModelScope.launch { repo.renameCharacter(characterId, name) }
    fun deleteCharacter(characterId: String) = viewModelScope.launch { repo.deleteCharacter(characterId) }
    fun renameScene(sceneId: String, name: String) = viewModelScope.launch { repo.renameScene(sceneId, name) }
    fun deleteScene(sceneId: String) = viewModelScope.launch { repo.deleteScene(sceneId) }
    fun renameProp(propId: String, name: String) = viewModelScope.launch { repo.renameProp(propId, name) }
    fun deleteProp(propId: String) = viewModelScope.launch { repo.deleteProp(propId) }
    fun bindCharacterVersion(shotId: String, characterId: String, versionId: String) = viewModelScope.launch {
        repo.bindCharacterVersion(shotId, characterId, versionId)
    }
    fun addScene(name: String) = viewModelScope.launch { repo.addScene(projectId, name) }
    fun addProp(name: String) = viewModelScope.launch { repo.addProp(projectId, name) }
    fun addSceneWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "scenes")
                repo.addScene(projectId, name, asset.absolutePath)
            }.onSuccess { done("场景卡图片已导入：$name") }
             .onFailure { done("场景图片导入失败：${it.message ?: "未知错误"}") }
        }
    fun addPropWithImage(name: String, uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "props")
                repo.addProp(projectId, name, asset.absolutePath)
            }.onSuccess { done("道具卡图片已导入：$name") }
             .onFailure { done("道具图片导入失败：${it.message ?: "未知错误"}") }
        }
    suspend fun loadScript(): String = repo.getProject(projectId)?.scriptText.orEmpty()
    fun saveScript(text: String) = viewModelScope.launch { repo.saveScript(projectId, text) }
    fun saveAndParseScript(text: String, done: (Int) -> Unit) = viewModelScope.launch {
        repo.saveScript(projectId, text)
        done(repo.importShotsFromScript(projectId, text))
    }
    fun saveShot(shot: ShotEntity) = viewModelScope.launch { repo.saveShot(shot) }
    fun addShot(title: String, index: Int) = viewModelScope.launch { repo.appendShot(projectId, index, title, "") }
    fun delete(id: String) = viewModelScope.launch { repo.deleteShot(id, projectId) }
    fun move(shot: ShotEntity, delta: Int, list: List<ShotEntity>) = viewModelScope.launch {
        val current = list.indexOfFirst { it.id == shot.id }
        val target = current + delta
        if (current < 0 || target !in list.indices) return@launch
        repo.swapShotOrder(list[current], list[target])
    }
    fun setLocked(characterId: String, locked: Boolean) = viewModelScope.launch { repo.setLocked(characterId, locked) }

    fun importCharacter(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, name: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.createCharacter(projectId, name, asset)
            }.onSuccess { done("角色卡「$name」已导入，已创建第 1 个版本") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importVersion(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, characterId: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "characters")
                repo.addCardVersion(characterId, asset)
            }.onSuccess { done("新角色卡版本已保存，旧版本保留") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importKeyframe(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, shotId: String, isFirst: Boolean, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "keyframes")
                val current = repo.getShot(shotId)
                if (current != null) {
                    repo.saveShot(if (isFirst) current.copy(firstFramePath = asset.absolutePath)
                    else current.copy(lastFramePath = asset.absolutePath))
                }
            }.onSuccess { done(if (isFirst) "首帧图片已导入" else "尾帧图片已导入") }
             .onFailure { done("导入失败：${it.message ?: "未知错误"}") }
        }

    fun importVideoClip(uri: Uri, resolver: android.content.ContentResolver, store: AssetStore, shotId: String, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val asset = store.importUri(resolver, uri, projectId, "videos")
                val current = repo.getShot(shotId)
                if (current != null) repo.saveShot(current.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { done("视频片段已导入") }
             .onFailure { done("视频导入失败：${it.message ?: "未知错误"}") }
        }

    fun extractLastFrameToNext(shot: ShotEntity, allShots: List<ShotEntity>, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val clip = shot.videoClipPath ?: error("该镜头还没有视频片段")
                val idx = allShots.indexOfFirst { it.id == shot.id }
                val nextShot = allShots.getOrNull(idx + 1) ?: error("已经是最后一镜，后面没有下一镜")
                val frameAsset = withContext(Dispatchers.IO) { store.extractLastFrame(clip, projectId) }
                repo.saveShot(nextShot.copy(firstFramePath = frameAsset.absolutePath))
                nextShot.title
            }.onSuccess { nextTitle -> done("已截取尾帧并设为「$nextTitle」的首帧") }
             .onFailure { done("截取失败：${it.message ?: "未知错误"}") }
        }

    fun aiGenerateScript(cfg: AiConfig, idea: String, done: (Boolean, String) -> Unit) =
        viewModelScope.launch {
            runCatching { AiClient.generateScript(cfg, idea) }
                .onSuccess { done(true, it) }
                .onFailure { done(false, it.message ?: "未知错误") }
        }

    fun aiGenerateFirstFrame(cfg: AiConfig, shot: ShotEntity, characterNames: List<String>, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val charPrefix = if (characterNames.isNotEmpty()) "featuring ${characterNames.joinToString(", ")}, " else ""
                val prompt = "$charPrefix${shot.title}. ${shot.description}"
                val bytes = AiClient.generateImageBytes(cfg, prompt)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "keyframes", "png") }
                repo.saveShot(shot.copy(firstFramePath = asset.absolutePath))
            }.onSuccess { done("已为「${shot.title}」生成首帧") }
             .onFailure { done("AI 生图失败：${it.message ?: "未知错误"}") }
        }

    fun aiGenerateVideo(cfg: AiConfig, shot: ShotEntity, store: AssetStore, done: (String) -> Unit) =
        viewModelScope.launch {
            runCatching {
                val prompt = "${shot.title}. ${shot.description}"
                val bytes = AiClient.generateVideoBytes(cfg, prompt, shot.firstFramePath)
                val asset = withContext(Dispatchers.IO) { store.saveBytes(bytes, projectId, "videos", "mp4") }
                repo.saveShot(shot.copy(videoClipPath = asset.absolutePath))
            }.onSuccess { done("已为「${shot.title}」生成视频片段") }
             .onFailure { done("AI 生视频失败：${it.message ?: "未知错误"}") }
        }

    class Factory(private val repo: WorkspaceRepository, private val id: String) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = WorkspaceViewModel(repo, id) as T
    }
}
