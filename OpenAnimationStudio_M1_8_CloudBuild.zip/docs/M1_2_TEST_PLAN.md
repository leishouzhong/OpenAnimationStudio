# M1.2 手动测试清单

> 当前为待执行测试；不要把清单视为已通过。

1. 安装 debug APK，首次启动不联网。
2. 创建项目，退出应用并重新打开，确认项目仍存在。
3. 打开项目，在“剧本”页输入文字并保存；切换页面后返回，检查数据。
4. 在“分镜”页连续添加 3 个镜头。
5. 将第 3 镜头上移，确认顺序交换；删除第 2 镜头，确认列表更新。
6. 强制停止应用后重启，检查项目和分镜仍存在。
7. 检查 AndroidManifest.xml，不应出现 android.permission.INTERNET。
8. 数据层验证：每个镜头绑定角色时，必须保存 characterId、cardVersionId、assetPathSnapshot 和 checksumSnapshot；切换角色当前版本不得改写既有绑定。
