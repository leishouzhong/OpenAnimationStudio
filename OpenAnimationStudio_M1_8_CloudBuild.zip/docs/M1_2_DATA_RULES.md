# M1.2 数据一致性规则

- ShotCharacterReferenceEntity 是镜头引用的版本快照，不应跟随角色的 activeVersionId 自动变化。
- 替换角色卡应新增 CharacterCardVersionEntity，而不是覆盖旧版本文件。
- GenerationSnapshotEntity 保存一次生成任务实际使用的输入快照。
- 删除镜头前，正式版本应在事务中清理 shot_character_references；本原型后续需补事务和外键级联。
- 当前分镜上/下移采用两条更新语句，正式版本应改为 Room @Transaction，避免中途退出产生重复序号。
