package org.openanimationstudio.data

import android.content.ContentResolver
import android.net.Uri
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class ImportedAsset(val absolutePath: String, val sha256: String, val fileName: String)

class AssetStore(private val root: File) {
    fun importUri(resolver: ContentResolver, uri: Uri, projectId: String, category: String): ImportedAsset {
        val folder = File(File(root, projectId), category).apply { mkdirs() }
        val target = File(folder, "${UUID.randomUUID()}.asset")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取所选文件" }.use { source ->
                target.outputStream().use { output -> source.copyTo(output) }
            }
        }
        val digest = MessageDigest.getInstance("SHA-256")
        target.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        return ImportedAsset(target.absolutePath, hash, target.name)
    }
}
