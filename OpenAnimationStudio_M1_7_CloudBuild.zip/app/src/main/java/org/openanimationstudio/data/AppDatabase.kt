package org.openanimationstudio.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProjectEntity::class, CharacterEntity::class, CharacterCardVersionEntity::class,
        ShotEntity::class, ShotCharacterReferenceEntity::class, GenerationSnapshotEntity::class,
        SceneEntity::class, PropEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `scenes` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS `props` (
                    `id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `name` TEXT NOT NULL,
                    `referenceImagePath` TEXT, `notes` TEXT NOT NULL, PRIMARY KEY(`id`))""")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startScale` REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endScale` REAL NOT NULL DEFAULT 1.08")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startOffsetX` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `startOffsetY` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endOffsetX` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `endOffsetY` REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `fadeInMs` INTEGER NOT NULL DEFAULT 300")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `fadeOutMs` INTEGER NOT NULL DEFAULT 300")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `audioPath` TEXT")
                db.execSQL("ALTER TABLE `shots` ADD COLUMN `audioStartMs` INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "open_animation_studio.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}
